import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'src/core.dart';
import 'teacher/auth.dart';
import 'teacher/home.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initSupabase();
  runApp(const TeacherApp());
}

class TeacherApp extends StatefulWidget {
  const TeacherApp({super.key});
  @override
  State<TeacherApp> createState() => _TeacherAppState();
}

class _TeacherAppState extends State<TeacherApp> {
  bool _loggedIn = false;

  @override
  void initState() {
    super.initState();
    _loggedIn = sb.auth.currentUser != null;
    WidgetsBinding.instance.addPostFrameCallback((_) => checkForUpdate(context, 'teacher'));
    sb.auth.onAuthStateChange.listen((e) {
      final logged = e.session != null;
      if (mounted && logged != _loggedIn) setState(() => _loggedIn = logged);
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'المنصة',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(teacher: true),
      home: _loggedIn ? const TeacherHome() : TeacherLoginPage(onLoggedIn: () => setState(() => _loggedIn = true)),
    );
  }
}
