import 'package:flutter/material.dart';
import '../src/core.dart';

class StudentsPage extends StatefulWidget {
  const StudentsPage({super.key});
  @override
  State<StudentsPage> createState() => _StudentsPageState();
}

class _StudentsPageState extends State<StudentsPage> {
  List _students = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await sb.from('students').select().order('created_at');
      if (mounted) setState(() { _students = r; _loading = false; });
    } catch (_) { if (mounted) { setState(() => _loading = false); toast(context, 'حصلت مشكلة في التحميل', err: true); } }
  }

  Future<void> _add() async {
    final name = TextEditingController();
    final phone = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('طالب جديد'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الطالب *')),
            const SizedBox(height: 10),
            TextField(controller: phone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, textAlign: TextAlign.left,
                decoration: const InputDecoration(labelText: 'واتساب ولي الأمر (اختياري)')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('أضف')),
          ],
        ),
      ),
    );
    if (ok != true || name.text.trim().isEmpty) return;
    try {
      await sb.from('students').insert({'teacher_id': sb.auth.currentUser!.id, 'name': name.text.trim(), 'parent_phone': phone.text.trim()});
      _load();
      if (mounted) toast(context, 'الطالب اتسجل');
    } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }

  Future<void> _delete(String id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('حذف الطالب؟'),
          content: const Text('درجاته وأكواده القديمة مش بتتمسح، بس هيشيله من سجل الطلبة.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لأ')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('أيوه، احذف')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try { await sb.from('students').delete().eq('id', id); _load(); } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('الطلبة')),
        floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.person_add_alt), label: const Text('طالب جديد')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _students.isEmpty
                ? Center(child: Text('مفيش طلبة لسه. سجّل أول طالب من الزرار تحت.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600)))
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: _students.length,
                      itemBuilder: (_, i) {
                        final s = _students[i];
                        return Card(
                          child: ListTile(
                            leading: CircleAvatar(backgroundColor: kNavy.withOpacity(0.1), child: const Icon(Icons.person_outline, color: kNavy)),
                            title: Text(s['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text((s['parent_phone'] ?? '').toString().isEmpty ? 'بدون رقم ولي أمر' : 'ولي الأمر: ${s['parent_phone']}'),
                            trailing: IconButton(icon: Icon(Icons.delete_outline, color: Colors.red.shade400), onPressed: () => _delete(s['id'])),
                          ),
                        );
                      },
                    ),
                  ),
      ),
    );
  }
}
