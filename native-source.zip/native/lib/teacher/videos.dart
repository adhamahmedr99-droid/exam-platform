import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../src/core.dart';

class VideosTab extends StatefulWidget {
  const VideosTab({super.key});
  @override
  State<VideosTab> createState() => _VideosTabState();
}

class _VideosTabState extends State<VideosTab> {
  List _videos = [];
  List _subs = [];
  bool _loading = true;
  String _stageFilter = '';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final uid = sb.auth.currentUser!.id;
      final vs = await sb.from('videos').select().eq('teacher_id', uid).order('created_at', ascending: false);
      final ss = await sb.from('video_students').select().eq('teacher_id', uid).order('created_at', ascending: false);
      if (mounted) setState(() { _videos = vs; _subs = ss; _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('فيديوهات الشرح')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(padding: const EdgeInsets.all(16), children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      const Text('أضف فيديو', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 4),
                      Text('حط لينك الفيديو (يوتيوب "غير مدرج" أو جوجل درايف). بيظهر للطلبة المشتركين بس.',
                          style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                      const SizedBox(height: 8),
                      ElevatedButton.icon(onPressed: _addVideo, icon: const Icon(Icons.video_library), label: const Text('أضف الفيديو')),
                    ]),
                  ),
                ),
                SizedBox(
                  height: 46,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(label: const Text('كل المراحل'), selected: _stageFilter.isEmpty, onSelected: (_) => setState(() => _stageFilter = ''))),
                      ...kStages.map((st) => Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(label: Text(st), selected: _stageFilter == st, onSelected: (_) => setState(() => _stageFilter = st)))),
                    ],
                  ),
                ),
                ..._videos.where((v) => _stageFilter.isEmpty || (v['grade'] ?? '') == _stageFilter).map((v) => Card(
                      child: ListTile(
                        leading: Icon(Icons.play_circle, color: v['active'] == true ? kTeal : Colors.grey, size: 30),
                        title: Text(v['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('${(v['grade'] ?? '').toString().isNotEmpty ? '${v['grade']} • ' : ''}${v['url'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                            icon: Icon(v['active'] == true ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20),
                            tooltip: v['active'] == true ? 'إخفاء' : 'إظهار',
                            onPressed: () async {
                              await sb.from('videos').update({'active': v['active'] != true}).eq('id', v['id']);
                              _load();
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline, size: 20, color: Colors.red),
                            onPressed: () async {
                              await sb.from('videos').delete().eq('id', v['id']);
                              _load();
                            },
                          ),
                        ]),
                      ),
                    )),
                const SizedBox(height: 12),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      const Text('الطلبة المشتركين', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 4),
                      Text('اعمل يوزر وباسورد لكل طالب دفع الاشتراك (الدفع فودافون كاش أو إنستاباي خارج المنصة). تقدر توقف اشتراك أي طالب في أي وقت.',
                          style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                      const SizedBox(height: 8),
                      ElevatedButton.icon(onPressed: _addSub, icon: const Icon(Icons.person_add), label: const Text('أضف المشترك')),
                    ]),
                  ),
                ),
                ..._subs.map((s) => Card(
                      child: ListTile(
                        leading: Icon(s['active'] == true ? Icons.check_circle : Icons.pause_circle,
                            color: s['active'] == true ? kTeal : Colors.grey),
                        title: Text(s['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('اليوزر: ${s['username']}'),
                        trailing: PopupMenuButton<String>(
                          onSelected: (v) => _subAction(v, s),
                          itemBuilder: (_) => [
                            PopupMenuItem(value: 'toggle', child: Text(s['active'] == true ? 'إيقاف الاشتراك' : 'تفعيل الاشتراك')),
                            const PopupMenuItem(value: 'reset', child: Text('باسورد جديد')),
                            const PopupMenuItem(value: 'delete', child: Text('حذف', style: TextStyle(color: Colors.red))),
                          ],
                        ),
                      ),
                    )),
              ]),
      ),
    );
  }

  Future<void> _addVideo() async {
    final title = TextEditingController();
    final url = TextEditingController();
    String stage = '';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('فيديو جديد'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: title, decoration: const InputDecoration(labelText: 'عنوان الفيديو *')),
            const SizedBox(height: 10),
            TextField(controller: url, textDirection: TextDirection.ltr, textAlign: TextAlign.left,
                decoration: const InputDecoration(labelText: 'لينك الفيديو *', hintText: 'https://')),
            const SizedBox(height: 10),
            StatefulBuilder(builder: (ctx2, setS) => DropdownButtonFormField<String>(
              value: stage.isEmpty ? null : stage,
              decoration: const InputDecoration(labelText: 'المرحلة / الصف'),
              items: kStages.map((st) => DropdownMenuItem(value: st, child: Text(st, style: const TextStyle(fontSize: 13)))).toList(),
              onChanged: (v) => setS(() => stage = v ?? ''),
            )),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة')),
          ],
        ),
      ),
    );
    if (ok != true || title.text.trim().isEmpty || url.text.trim().isEmpty) return;
    final u = url.text.trim();
    if (ytId(u).isEmpty && driveId(u).isEmpty) {
      if (mounted) toast(context, 'اللينك لازم يكون يوتيوب أو جوجل درايف', err: true);
      return;
    }
    try {
      await sb.from('videos').insert({'teacher_id': sb.auth.currentUser!.id, 'title': title.text.trim(), 'url': u, 'grade': stage});
      _load();
      if (mounted) toast(context, 'الفيديو اتضاف');
    } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }

  Future<void> _addSub() async {
    final name = TextEditingController();
    final user = TextEditingController();
    final pass = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('مشترك جديد'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الطالب *')),
            const SizedBox(height: 10),
            TextField(controller: user, textDirection: TextDirection.ltr, textAlign: TextAlign.left,
                decoration: const InputDecoration(labelText: 'اسم المستخدم (إنجليزي من غير مسافات) *')),
            const SizedBox(height: 10),
            PwField(controller: pass, label: 'كلمة السر *'),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إضافة')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      final r = await sb.rpc('create_video_student', params: {
        'p_name': name.text.trim(), 'p_username': user.text.trim(), 'p_password': pass.text,
      });
      if (r['ok'] != true) {
        final m = {
          'bad_username': 'اسم المستخدم لازم يكون 3 حروف إنجليزي أو أرقام على الأقل من غير مسافات.',
          'bad_password': 'كلمة السر لازم تكون 8 حروف على الأقل.',
          'taken': 'اسم المستخدم ده متاخد، جرب اسم تاني.',
          'auth': 'سجّل دخول من الأول.',
        };
        if (mounted) toast(context, m[r['error']] ?? 'حصلت مشكلة، جرب تاني', err: true);
        return;
      }
      _load();
      if (mounted) toast(context, 'المشترك اتضاف');
    } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }

  Future<void> _subAction(String action, Map s) async {
    try {
      if (action == 'toggle') {
        await sb.from('video_students').update({'active': s['active'] != true}).eq('id', s['id']);
      } else if (action == 'delete') {
        await sb.from('video_students').delete().eq('id', s['id']);
      } else if (action == 'reset') {
        final pass = TextEditingController();
        final ok = await showDialog<bool>(
          context: context,
          builder: (ctx) => Directionality(
            textDirection: TextDirection.rtl,
            child: AlertDialog(
              title: const Text('باسورد جديد'),
              content: PwField(controller: pass, label: 'كلمة السر الجديدة'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
              ],
            ),
          ),
        );
        if (ok != true || pass.text.length < 8) { if (mounted) toast(context, 'كلمة السر لازم تكون 8 حروف على الأقل.', err: true); return; }
        final r = await sb.rpc('reset_video_student_password', params: {'p_student': s['id'], 'p_password': pass.text});
        if (r['ok'] != true) { if (mounted) toast(context, 'حصلت مشكلة', err: true); return; }
        if (mounted) toast(context, 'الباسورد اتغير');
      }
      _load();
    } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }
}
