import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../src/core.dart';

class ExamsTab extends StatefulWidget {
  const ExamsTab({super.key});
  @override
  State<ExamsTab> createState() => _ExamsTabState();
}

class _ExamsTabState extends State<ExamsTab> {
  List _exams = [];
  bool _loading = true;
  String _stageFilter = '';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final uid = sb.auth.currentUser!.id;
      final rows = await sb.from('exams').select().eq('teacher_id', uid).order('created_at', ascending: false);
      if (mounted) setState(() { _exams = rows; _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _create() async {
    final made = await Navigator.push(context, MaterialPageRoute(builder: (_) => const ExamFormPage()));
    if (made != null && mounted) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => ExamDetailPage(exam: made))).then((_) => _load());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الامتحانات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create, backgroundColor: kNavy, foregroundColor: Colors.white,
        icon: const Icon(Icons.add), label: const Text('امتحان جديد'),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _exams.isEmpty
                ? ListView(children: [
                    const SizedBox(height: 120),
                    Icon(Icons.assignment_outlined, size: 64, color: Colors.grey.shade400),
                    const SizedBox(height: 12),
                    Text('مفيش امتحانات لسه\nدوس "امتحان جديد" وابدأ', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600, fontSize: 15)),
                  ])
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _exams.where((e) => _stageFilter.isEmpty || (e['grade'] ?? '') == _stageFilter).length + 1,
                    itemBuilder: (_, i) {
                      if (i == 0) {
                        return SizedBox(
                          height: 46,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(label: const Text('كل المراحل'), selected: _stageFilter.isEmpty, onSelected: (_) => setState(() => _stageFilter = ''))),
                              ...kStages.map((st) => Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(label: Text(st), selected: _stageFilter == st, onSelected: (_) => setState(() => _stageFilter = st)))),
                            ],
                          ),
                        );
                      }
                      final e = _exams.where((e) => _stageFilter.isEmpty || (e['grade'] ?? '') == _stageFilter).toList()[i - 1];
                      return Card(
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          leading: CircleAvatar(
                            backgroundColor: (e['published'] == true ? kTeal : Colors.grey).withOpacity(0.15),
                            child: Icon(Icons.assignment, color: e['published'] == true ? kTeal : Colors.grey),
                          ),
                          title: Text(e['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w800)),
                          subtitle: Text('${e['subject'] ?? ''} ${e['grade'] ?? ''} • ${e['duration_min']} دقيقة • ${e['published'] == true ? 'منشور' : 'مسودة'}'),
                          trailing: const Icon(Icons.chevron_left),
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExamDetailPage(exam: e))).then((_) => _load()),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}

// ---------- Exam create/edit form ----------
class ExamFormPage extends StatefulWidget {
  final Map? exam;
  const ExamFormPage({super.key, this.exam});
  @override
  State<ExamFormPage> createState() => _ExamFormPageState();
}

class _ExamFormPageState extends State<ExamFormPage> {
  final _title = TextEditingController();
  final _subject = TextEditingController();
  final _grade = TextEditingController();
  final _desc = TextEditingController();
  final _duration = TextEditingController(text: '15');
  final _pass = TextEditingController(text: '50');
  bool _shuffleQ = true, _shuffleC = true, _showResult = true, _published = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final e = widget.exam;
    if (e != null) {
      _title.text = e['title'] ?? ''; _subject.text = e['subject'] ?? ''; _grade.text = e['grade'] ?? '';
      _desc.text = e['description'] ?? ''; _duration.text = '${e['duration_min'] ?? 15}'; _pass.text = '${e['pass_pct'] ?? 50}';
      _shuffleQ = e['shuffle_q'] ?? true; _shuffleC = e['shuffle_c'] ?? true;
      _showResult = e['show_result'] ?? true; _published = e['published'] ?? false;
    }
  }

  Future<void> _save() async {
    if (_title.text.trim().isEmpty) { toast(context, 'اكتب عنوان الامتحان', err: true); return; }
    setState(() => _busy = true);
    final row = {
      'title': _title.text.trim(), 'subject': _subject.text.trim(), 'grade': _grade.text.trim(),
      'description': _desc.text.trim(),
      'duration_min': int.tryParse(_duration.text) ?? 15,
      'pass_pct': int.tryParse(_pass.text) ?? 50,
      'shuffle_q': _shuffleQ, 'shuffle_c': _shuffleC, 'show_result': _showResult, 'published': _published,
    };
    try {
      Map saved;
      if (widget.exam == null) {
        row['teacher_id'] = sb.auth.currentUser!.id;
        saved = await sb.from('exams').insert(row).select().single();
      } else {
        saved = await sb.from('exams').update(row).eq('id', widget.exam!['id']).select().single();
      }
      if (mounted) Navigator.pop(context, saved);
    } catch (_) {
      if (mounted) { toast(context, 'حصلت مشكلة في الحفظ', err: true); setState(() => _busy = false); }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.exam == null ? 'امتحان جديد' : 'تعديل الامتحان')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          TextField(controller: _title, decoration: const InputDecoration(labelText: 'عنوان الامتحان *')),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: TextField(controller: _subject, decoration: const InputDecoration(labelText: 'المادة'))),
            const SizedBox(width: 12),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: kStages.contains(_grade.text) ? _grade.text : null,
                decoration: const InputDecoration(labelText: 'المرحلة / الصف'),
                items: kStages.map((st) => DropdownMenuItem(value: st, child: Text(st, style: const TextStyle(fontSize: 13)))).toList(),
                onChanged: (v) => setState(() => _grade.text = v ?? ''),
              ),
            ),
          ]),
          const SizedBox(height: 12),
          TextField(controller: _desc, maxLines: 2, decoration: const InputDecoration(labelText: 'وصف (اختياري)')),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: TextField(controller: _duration, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المدة (دقيقة)'))),
            const SizedBox(width: 12),
            Expanded(child: TextField(controller: _pass, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'نسبة النجاح %'))),
          ]),
          const SizedBox(height: 8),
          SwitchListTile(value: _shuffleQ, onChanged: (v) => setState(() => _shuffleQ = v), title: const Text('خلط ترتيب الأسئلة'), dense: true),
          SwitchListTile(value: _shuffleC, onChanged: (v) => setState(() => _shuffleC = v), title: const Text('خلط ترتيب الاختيارات'), dense: true),
          SwitchListTile(value: _showResult, onChanged: (v) => setState(() => _showResult = v), title: const Text('إظهار النتيجة للطالب بعد التسليم'), dense: true),
          SwitchListTile(value: _published, onChanged: (v) => setState(() => _published = v), title: const Text('منشور (الطلبة يقدروا يدخلوا)'), dense: true),
          const SizedBox(height: 16),
          BusyBtn(label: widget.exam == null ? 'إنشاء الامتحان' : 'حفظ التعديلات', busy: _busy, onTap: _save, icon: Icons.check),
        ]),
      ),
    );
  }
}

// ---------- Exam detail ----------
class ExamDetailPage extends StatefulWidget {
  final Map exam;
  const ExamDetailPage({super.key, required this.exam});
  @override
  State<ExamDetailPage> createState() => _ExamDetailPageState();
}

class _ExamDetailPageState extends State<ExamDetailPage> {
  late Map _exam;
  List _questions = [];
  List _codes = [];
  List _subs = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _exam = widget.exam; _load(); }

  Future<void> _load() async {
    try {
      final id = _exam['id'];
      final qs = await sb.from('questions').select().eq('exam_id', id).order('ord');
      final cs = await sb.rpc('exam_code_status', params: {'p_exam': id});
      final subs = await sb.from('submissions')
          .select('*, exam_sessions!inner(codes!inner(student_name, exam_id, token))')
          .eq('exam_sessions.codes.exam_id', id);
      final fresh = await sb.from('exams').select().eq('id', id).single();
      if (mounted) setState(() { _exam = fresh; _questions = qs; _codes = cs; _subs = subs; _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: Text(_exam['title'] ?? ''),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExamFormPage(exam: _exam))).then((v) { if (v != null) _load(); }),
              ),
            ],
            bottom: const TabBar(
              labelColor: Colors.white, unselectedLabelColor: Colors.white60, indicatorColor: kTeal,
              tabs: [Tab(text: 'الأسئلة'), Tab(text: 'الأكواد'), Tab(text: 'النتائج')],
            ),
          ),
          body: _loading
              ? const Center(child: CircularProgressIndicator())
              : TabBarView(children: [_questionsTab(), _codesTab(), _resultsTab()]),
        ),
      ),
    );
  }

  Widget _questionsTab() {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton(
        onPressed: () => _editQuestion(null), backgroundColor: kNavy, foregroundColor: Colors.white, child: const Icon(Icons.add),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _importing ? null : _importFromPhotos,
              icon: const Icon(Icons.photo_camera_outlined),
              label: Text(_importing ? 'بقرا الصور... ممكن ياخد دقيقة' : 'إضافة أسئلة من صور'),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
          child: SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _importing ? null : _importFromJson,
              icon: const Icon(Icons.upload_file),
              label: const Text('استيراد أسئلة من ملف JSON'),
            ),
          ),
        ),
        if (_importing) const LinearProgressIndicator(),
        Expanded(child: _questions.isEmpty
          ? Center(child: Text('مفيش أسئلة لسه. دوس + وضيف أول سؤال، أو صوّر ورقة الامتحان.', style: TextStyle(color: Colors.grey.shade600)))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _questions.length,
              itemBuilder: (_, i) {
                final q = _questions[i];
                final typeName = {'mcq': 'اختياري', 'tf': 'صح وغلط', 'sa': 'إجابة قصيرة', 'essay': 'مقالي'}[q['type']] ?? q['type'];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(radius: 14, child: Text('${i + 1}', style: const TextStyle(fontSize: 13))),
                    title: Text(q['text'] ?? '', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text('$typeName • ${q['points']} درجة'),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(icon: const Icon(Icons.edit_outlined, size: 20), onPressed: () => _editQuestion(q)),
                      IconButton(icon: const Icon(Icons.delete_outline, size: 20, color: Colors.red), onPressed: () => _delQuestion(q)),
                    ]),
                  ),
                );
              },
            ),
        ),
      ]),
    );
  }

  bool _importing = false;

  Future<void> _importFromJson() async {
    final picked = await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
    if (picked == null || picked.files.isEmpty) return;
    final f = picked.files.first;
    setState(() => _importing = true);
    try {
      var bytes = f.bytes;
      if (bytes == null && f.path != null) bytes = await File(f.path!).readAsBytes();
      if (bytes == null) throw 'مقدرتش أقرا الملف.';
      if (bytes.length > 500000) throw 'الملف كبير جدًا. الحد الأقصى ٥٠٠ كيلوبايت.';
      dynamic data;
      try { data = jsonDecode(utf8.decode(bytes)); } catch (_) { throw 'الملف مش JSON صالح. اختار ملف الامتحان الأصلي.'; }
      final rows = data is List ? data : (data is Map ? data['questions'] : null);
      if (rows is! List || rows.isEmpty || rows.length > 100) throw 'لازم الملف يحتوي من ١ إلى ١٠٠ سؤال.';
      final out = <Map<String, dynamic>>[];
      for (var i = 0; i < rows.length; i++) {
        final q = rows[i];
        if (q is! Map || q['text'] is! String || (q['text'] as String).trim().isEmpty) throw 'نص السؤال ${i + 1} ناقص.';
        if (q['type'] != null && q['type'] != 'mcq') throw 'الاستيراد بيدعم الاختيار من متعدد بس.';
        final ch = q['choices'];
        if (ch is! List || ch.length < 2 || ch.length > 6 || ch.any((c) => c is! String || c.trim().isEmpty)) throw 'راجع اختيارات السؤال ${i + 1}.';
        final c = q['correct'];
        if (c is! int || c < 0 || c >= ch.length) throw 'الإجابة الصحيحة للسؤال ${i + 1} مش محددة صح.';
        final pts = q['points'] ?? 1;
        if (![1, 2, 3, 5, 10].contains(pts)) throw 'درجة السؤال ${i + 1} غير مدعومة.';
        out.add({'text': (q['text'] as String).trim(), 'choices': ch.map((e) => (e as String).trim()).toList(), 'correct': c, 'points': pts});
      }
      var ord = _questions.length;
      for (final q in out) {
        await sb.from('questions').insert({
          'exam_id': _exam['id'], 'ord': ord, 'text': q['text'], 'type': 'mcq',
          'points': q['points'], 'choices': q['choices'], 'correct': q['correct'], 'accepted': null,
        });
        ord++;
      }
      if (mounted) toast(context, 'اتضاف ${out.length} سؤال من الملف. راجعهم.');
      _load();
    } catch (e) {
      if (mounted) toast(context, e is String ? e : 'حصلت مشكلة في الاستيراد: $e', err: true);
    } finally {
      if (mounted) setState(() => _importing = false);
    }
  }

  Future<void> _importFromPhotos() async {
    final files = await ImagePicker().pickMultiImage(maxWidth: 1600, imageQuality: 70);
    if (files.isEmpty) return;
    setState(() => _importing = true);
    try {
      final picked = files.take(6).toList();
      final rows = <dynamic>[];
      final failed = <int>[];
      String lastErr = '';
      var done = 0;
      Future<void> one(int idx) async {
        try {
          final b64 = base64Encode(await picked[idx].readAsBytes());
          final res = await sb.functions.invoke('exam-from-photo', body: {'images': [b64]}).timeout(const Duration(seconds: 95));
          final out = res.data;
          if (out is Map && out['questions'] is List) rows.addAll(out['questions'] as List);
        } catch (e) {
          failed.add(idx + 1);
          final t = '$e';
          lastErr = t.contains('Timeout') ? 'الصورة خدت وقت طويل، جرّب صورة أوضح أو أصغر.'
              : t.contains('429') ? 'الخدمة مزدحمة، استنى دقيقة وجرّب تاني.'
              : (t.contains('SocketException') || t.contains('ClientException')) ? 'مفيش اتصال بالنت أو النت ضعيف.'
              : t.contains('401') ? 'سجّل دخول تاني وجرّب.' : 'الخدمة مش متاحة دلوقتي، جرّب تاني بعد شوية.';
        }
        done++;
        if (mounted) toast(context, 'خلّصت $done من ${picked.length} صورة');
      }
      var next = 0;
      Future<void> worker() async { while (next < picked.length) { final i = next++; await one(i); } }
      await Future.wait([worker(), worker()]);
      if (rows.isEmpty && failed.isNotEmpty) throw lastErr;
      if (rows.isEmpty) throw 'مش لاقي أسئلة اختيار من متعدد في الصور. صوّر أوضح وجرّب تاني.';
      var ord = _questions.length;
      var added = 0;
      final guessed = <int>[];
      for (final q in rows) {
        if (q is! Map || q['choices'] is! List) continue;
        final choices = (q['choices'] as List).map((c) => '$c').toList();
        if (choices.length < 2) continue;
        var correct = q['correct'] is int ? q['correct'] as int : (int.tryParse('${q['correct']}') ?? 0);
        if (correct < 0 || correct >= choices.length) correct = 0;
        if (q['answer_source'] == 'guessed') guessed.add(ord + 1);
        await sb.from('questions').insert({
          'exam_id': _exam['id'], 'ord': ord, 'text': '${q['text'] ?? ''}', 'type': 'mcq',
          'points': 1, 'choices': choices, 'correct': correct, 'accepted': null,
        });
        ord++; added++;
      }
      if (added == 0) throw 'مش لاقي أسئلة صالحة في الصور. جرّب تاني.';
      if (mounted) {
        await showDialog(context: context, builder: (_) => Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: const Text('اتضافت الأسئلة'),
            content: Text('اتضاف $added سؤال من الصور.' + (failed.isEmpty ? '' : '\n\nالصور رقم ${failed.join('، ')} ماتقراتش ($lastErr) جرّبهم تاني.') + (guessed.isEmpty ? '' : '\n\nالإجابة الصحيحة للأسئلة رقم ${guessed.join('، ')} مكانتش معلّمة في الصورة والذكاء الاصطناعي اختارها — راجعها.') + '\n\nراجع الأسئلة والاختيارات كويس (القراءة من الصور ممكن تغلط).'),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('تمام'))],
          ),
        ));
      }
      _load();
    } catch (e) {
      if (mounted) toast(context, e is String ? e : 'الخدمة مش متاحة دلوقتي، جرّب تاني بعد شوية.', err: true);
    } finally {
      if (mounted) setState(() => _importing = false);
    }
  }

  Future<void> _editQuestion(Map? q) async {
    final saved = await showModalBottomSheet<bool>(
      context: context, isScrollControlled: true,
      builder: (_) => Padding(padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom), child: QuestionSheet(examId: _exam['id'], question: q, ord: _questions.length)),
    );
    if (saved == true) _load();
  }

  Future<void> _delQuestion(Map q) async {
    final yes = await _confirm(context, 'حذف السؤال ده؟');
    if (yes != true) return;
    try { await sb.from('questions').delete().eq('id', q['id']); _load(); } catch (_) {
      if (mounted) toast(context, 'حصلت مشكلة', err: true);
    }
  }

  Widget _codesTab() {
    final openLink = '$kSiteUrl#/o/${_exam['open_token'] ?? ''}';
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('لينك مفتوح', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 4),
            Text('أي حد معاه اللينك يدخل يكتب اسمه ويحل (من غير كود).', style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
            SwitchListTile(
              value: _exam['open_enabled'] == true, dense: true, contentPadding: EdgeInsets.zero,
              title: const Text('تفعيل اللينك المفتوح'),
              onChanged: (v) async {
                final row = <String, dynamic>{'open_enabled': v};
                if (v && (_exam['open_token'] == null)) row['open_token'] = newToken();
                try {
                  await sb.from('exams').update(row).eq('id', _exam['id']);
                  _load();
                } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
              },
            ),
            if (_exam['open_enabled'] == true && _exam['open_token'] != null)
              OutlinedButton.icon(
                onPressed: () { Clipboard.setData(ClipboardData(text: openLink)); toast(context, 'اللينك اتنسخ'); },
                icon: const Icon(Icons.copy, size: 18), label: const Text('نسخ اللينك'),
              ),
          ]),
        ),
      ),
      const SizedBox(height: 8),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('كود لطالب', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 4),
            Text('كل كود بيشتغل مرة واحدة بس للطالب اللي هتكتب اسمه.', style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
            const SizedBox(height: 8),
            ElevatedButton.icon(onPressed: _addCode, icon: const Icon(Icons.person_add), label: const Text('إنشاء كود')),
          ]),
        ),
      ),
      const SizedBox(height: 8),
      ..._codes.map((c) => Card(
            child: ListTile(
              leading: Icon(c['status'] == 'completed' ? Icons.check_circle : c['status'] == 'in_progress' ? Icons.timelapse : Icons.key,
                  color: c['status'] == 'completed' ? kTeal : c['status'] == 'in_progress' ? kGold : Colors.grey),
              title: Text(c['student_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${c['via'] == 'open' ? 'دخل باللينك' : 'الكود: ${c['token']}'} • ${_codeStatus(c['status'])}'),
              trailing: c['via'] == 'open'
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.copy, size: 20),
                      onPressed: () { Clipboard.setData(ClipboardData(text: c['token'] ?? '')); toast(context, 'الكود اتنسخ'); },
                    ),
            ),
          )),
    ]);
  }

  String _codeStatus(String? s) => {'unused': 'مستني', 'in_progress': 'بيحل دلوقتي', 'completed': 'خلّص'}[s] ?? (s ?? '');

  Future<void> _addCode() async {
    final name = TextEditingController();
    final phone = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('كود جديد'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الطالب *')),
            const SizedBox(height: 10),
            TextField(controller: phone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, textAlign: TextAlign.left,
                decoration: const InputDecoration(labelText: 'موبايل ولي الأمر (اختياري)')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إنشاء')),
          ],
        ),
      ),
    );
    if (ok != true || name.text.trim().isEmpty) return;
    try {
      // upsert student record too (for the students list)
      final uid = sb.auth.currentUser!.id;
      await sb.from('students').insert({'teacher_id': uid, 'name': name.text.trim(), 'parent_phone': phone.text.trim()});
      await sb.from('codes').insert({
        'exam_id': _exam['id'], 'student_name': name.text.trim(), 'token': newToken(), 'parent_phone': phone.text.trim(),
      });
      _load();
      if (mounted) toast(context, 'الكود اتعمل');
    } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }

  Widget _resultsTab() {
    if (_subs.isEmpty) return Center(child: Text('مفيش نتايج لسه.', style: TextStyle(color: Colors.grey.shade600)));
    final passPct = (_exam['pass_pct'] ?? 50) as num;
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _subs.length,
      itemBuilder: (_, i) {
        final s = _subs[i];
        final name = s['exam_sessions']?['codes']?['student_name'] ?? '';
        final score = s['auto_score'] as num, total = s['auto_total'] as num;
        final p = total == 0 ? 0 : (score / total * 100).round();
        final passed = p >= passPct;
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: (passed ? kTeal : Colors.red).withOpacity(0.15),
              child: Icon(passed ? Icons.check : Icons.close, color: passed ? kTeal : Colors.red),
            ),
            title: Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('${s['correct_count']}/${s['n_auto']} صح • الوقت: ${(s['time_sec'] as num) ~/ 60}:${((s['time_sec'] as num) % 60).toString().padLeft(2, '0')}${s['auto'] == true ? ' • تسليم تلقائي' : ''}'),
            trailing: Text('$score/$total\n($p%)', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        );
      },
    );
  }
}

// ---------- Question editor sheet ----------
class QuestionSheet extends StatefulWidget {
  final String examId;
  final Map? question;
  final int ord;
  const QuestionSheet({super.key, required this.examId, this.question, required this.ord});
  @override
  State<QuestionSheet> createState() => _QuestionSheetState();
}

class _QuestionSheetState extends State<QuestionSheet> {
  final _text = TextEditingController();
  final _points = TextEditingController(text: '1');
  final _accepted = TextEditingController();
  String _type = 'mcq';
  List<TextEditingController> _choices = [TextEditingController(), TextEditingController()];
  int _correct = 0;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final q = widget.question;
    if (q != null) {
      _text.text = q['text'] ?? ''; _type = q['type'] ?? 'mcq';
      _points.text = '${q['points'] ?? 1}';
      if (_type == 'mcq' && q['choices'] is List) {
        _choices = (q['choices'] as List).map((c) => TextEditingController(text: '$c')).toList();
        if (_choices.length < 2) while (_choices.length < 2) { _choices.add(TextEditingController()); }
        _correct = q['correct'] ?? 0;
      }
      if (_type == 'sa' && q['accepted'] is List) _accepted.text = (q['accepted'] as List).join('، ');
      if (_type == 'tf') _correct = q['correct'] ?? 0;
    }
  }

  Future<void> _save() async {
    if (_text.text.trim().isEmpty) { toast(context, 'اكتب نص السؤال', err: true); return; }
    if (_type == 'mcq' && _choices.where((c) => c.text.trim().isNotEmpty).length < 2) {
      toast(context, 'لازم اختيارين على الأقل', err: true); return;
    }
    setState(() => _busy = true);
    final row = <String, dynamic>{
      'exam_id': widget.examId, 'text': _text.text.trim(), 'type': _type,
      'points': num.tryParse(_points.text) ?? 1,
      'choices': null, 'correct': null, 'accepted': null,
    };
    if (_type == 'mcq') {
      final cs = _choices.map((c) => c.text.trim()).where((c) => c.isNotEmpty).toList();
      row['choices'] = cs;
      row['correct'] = _correct.clamp(0, cs.length - 1);
    } else if (_type == 'tf') {
      row['choices'] = ['صح', 'غلط'];
      row['correct'] = _correct;
    } else if (_type == 'sa') {
      row['accepted'] = _accepted.text.split(RegExp('[،,]')).map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
    }
    try {
      if (widget.question == null) {
        row['ord'] = widget.ord;
        await sb.from('questions').insert(row);
      } else {
        await sb.from('questions').update(row).eq('id', widget.question!['id']);
      }
      if (mounted) Navigator.pop(context, true);
    } catch (_) {
      if (mounted) { toast(context, 'حصلت مشكلة في الحفظ', err: true); setState(() => _busy = false); }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(shrinkWrap: true, children: [
          Text(widget.question == null ? 'سؤال جديد' : 'تعديل السؤال', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'mcq', label: Text('اختياري')),
              ButtonSegment(value: 'tf', label: Text('صح/غلط')),
              ButtonSegment(value: 'sa', label: Text('قصيرة')),
              ButtonSegment(value: 'essay', label: Text('مقالي')),
            ],
            selected: {_type},
            onSelectionChanged: (s) => setState(() => _type = s.first),
          ),
          const SizedBox(height: 12),
          TextField(controller: _text, maxLines: 3, decoration: const InputDecoration(labelText: 'نص السؤال *')),
          const SizedBox(height: 12),
          if (_type == 'mcq') ...[
            const Text('الاختيارات (علّم على الإجابة الصح):', style: TextStyle(fontWeight: FontWeight.w700)),
            ...List.generate(_choices.length, (i) => Row(children: [
                  Radio<int>(value: i, groupValue: _correct, onChanged: (v) => setState(() => _correct = v!)),
                  Expanded(child: TextField(controller: _choices[i], decoration: InputDecoration(labelText: 'اختيار ${i + 1}'))),
                  if (_choices.length > 2)
                    IconButton(icon: const Icon(Icons.remove_circle_outline, color: Colors.red), onPressed: () => setState(() => _choices.removeAt(i))),
                ])),
            TextButton.icon(onPressed: () => setState(() => _choices.add(TextEditingController())), icon: const Icon(Icons.add), label: const Text('ضيف اختيار')),
          ],
          if (_type == 'tf')
            Row(children: [
              Expanded(child: RadioListTile<int>(value: 0, groupValue: _correct, onChanged: (v) => setState(() => _correct = v!), title: const Text('صح'))),
              Expanded(child: RadioListTile<int>(value: 1, groupValue: _correct, onChanged: (v) => setState(() => _correct = v!), title: const Text('غلط'))),
            ]),
          if (_type == 'sa')
            TextField(controller: _accepted, decoration: const InputDecoration(labelText: 'الإجابات المقبولة (افصل بينهم بفاصلة)')),
          const SizedBox(height: 12),
          TextField(controller: _points, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الدرجة')),
          const SizedBox(height: 16),
          BusyBtn(label: 'حفظ السؤال', busy: _busy, onTap: _save, icon: Icons.check),
        ]),
      ),
    );
  }
}

Future<bool?> _confirm(BuildContext context, String msg) {
  return showDialog<bool>(
    context: context,
    builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        content: Text(msg),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لأ')),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.red), onPressed: () => Navigator.pop(ctx, true), child: const Text('أيوه')),
        ],
      ),
    ),
  );
}
