import 'package:flutter/material.dart';
import '../src/core.dart';

class AnalyticsPage extends StatefulWidget {
  const AnalyticsPage({super.key});
  @override
  State<AnalyticsPage> createState() => _AnalyticsPageState();
}

class _AnalyticsPageState extends State<AnalyticsPage> {
  List _exams = [];
  List _subs = [];
  List _questions = [];
  Map<String, num> _gsum = {};
  Map? _exam;
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final exams = await sb.from('exams').select('id,title,pass_pct').order('created_at', ascending: false);
      final subs = await sb.from('submissions')
          .select('*, exam_sessions(code_id, codes(student_name, exam_id))')
          .order('submitted_at', ascending: false);
      final grades = await sb.from('essay_grades').select('*');
      final gsum = <String, num>{};
      for (final g in grades) { gsum[g['submission_id']] = (gsum[g['submission_id']] ?? 0) + (g['awarded'] as num); }
      if (!mounted) return;
      _exams = exams; _subs = subs; _gsum = gsum;
      final withRes = exams.where((e) => subs.any((s) => s['exam_sessions']?['codes']?['exam_id'] == e['id'])).toList();
      if (withRes.isEmpty) { setState(() { _exam = null; _loading = false; }); return; }
      final exam = withRes.firstWhere((e) => _exam != null && e['id'] == _exam!['id'], orElse: () => withRes.first);
      final qs = await sb.from('questions').select('id,text,type,points').eq('exam_id', exam['id']).order('ord');
      if (mounted) setState(() { _exam = exam; _questions = qs; _loading = false; });
    } catch (_) { if (mounted) { setState(() => _loading = false); toast(context, 'حصلت مشكلة في التحميل', err: true); } }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('التحليلات')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _exam == null
                ? Center(child: Text('مفيش بيانات لسه، أول ما تيجي نتايج هتظهر هنا.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600)))
                : _body(),
      ),
    );
  }

  Widget _body() {
    final examId = _exam!['id'];
    final rows = _subs.where((s) => s['exam_sessions']?['codes']?['exam_id'] == examId).toList();
    final essayMax = _questions.where((q) => q['type'] == 'essay').fold<num>(0, (a, q) => a + (q['points'] as num));
    num finalPct(Map s) {
      final t = (s['auto_total'] as num) + essayMax;
      return t == 0 ? 0 : (((s['auto_score'] as num) + (_gsum[s['id']] ?? 0)) * 1000 / t).round() / 10;
    }
    final pcts = rows.map((s) => finalPct(s as Map)).toList();
    final avg = pcts.isEmpty ? 0 : (pcts.fold<num>(0, (a, b) => a + b) / pcts.length).round();
    final passRate = pcts.isEmpty ? 0 : (pcts.where((p) => p >= (_exam!['pass_pct'] as num)).length * 100 / pcts.length).round();
    final auto = _questions.where((q) => q['type'] != 'essay').toList();
    final qStats = auto.asMap().entries.map((e) {
      final i = e.key;
      final att = rows.where((r) => (r['bitmap'] ?? '').length > i).toList();
      final ok = att.where((r) => r['bitmap'][i] == '1').length;
      return {'q': e.value, 'pct': att.isEmpty ? 0 : (ok * 100 / att.length).round(), 'n': att.length};
    }).toList();
    final ranked = rows.toList()..sort((a, b) => finalPct(b).compareTo(finalPct(a)));
    final missed = qStats.toList()..sort((a, b) => (a['pct'] as int).compareTo(b['pct'] as int));
    final withRes = _exams.where((e) => _subs.any((s) => s['exam_sessions']?['codes']?['exam_id'] == e['id'])).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      if (withRes.length > 1)
        DropdownButtonFormField<String>(
          value: _exam!['id'] as String,
          decoration: const InputDecoration(labelText: 'الامتحان'),
          items: withRes.map<DropdownMenuItem<String>>((e) => DropdownMenuItem(value: e['id'] as String, child: Text(e['title'] ?? ''))).toList(),
          onChanged: (v) { setState(() => _exam = _exams.firstWhere((e) => e['id'] == v)); _load(); },
        ),
      const SizedBox(height: 8),
      Row(children: [_stat('تسليم', '${rows.length}'), _stat('المتوسط', '$avg%'), _stat('أعلى', '${pcts.isEmpty ? 0 : pcts.reduce((a, b) => a > b ? a : b)}%')]),
      Row(children: [_stat('أقل', '${pcts.isEmpty ? 0 : pcts.reduce((a, b) => a < b ? a : b)}%'), _stat('نسبة النجاح', '$passRate%'), _stat('أسئلة', '${_questions.length}')]),
      const SizedBox(height: 8),
      Card(child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('ترتيب الطلبة', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 8),
          ...ranked.asMap().entries.map((e) {
            final s = e.value;
            final p = finalPct(s);
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Row(children: [
                SizedBox(width: 26, child: Text('${e.key + 1}.', style: TextStyle(color: Colors.grey.shade500))),
                Expanded(child: Text(s['exam_sessions']?['codes']?['student_name'] ?? '—', style: const TextStyle(fontWeight: FontWeight.w700))),
                Text('$p%', style: const TextStyle(fontWeight: FontWeight.w900)),
              ]),
            );
          }),
        ]),
      )),
      Card(child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('صعوبة الأسئلة (نسبة الصح)', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 10),
          ...qStats.asMap().entries.map((e) {
            final st = e.value;
            final qt = (st['q']['text'] ?? '').toString();
            final pctv = st['pct'] as int;
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text('س${e.key + 1}: ${qt.length > 50 ? '${qt.substring(0, 49)}…' : qt}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Row(children: [
                  Expanded(child: ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(value: pctv / 100, minHeight: 8, backgroundColor: Colors.grey.shade200, color: pctv >= 60 ? kTeal : (pctv >= 40 ? kGold : Colors.red)),
                  )),
                  const SizedBox(width: 8),
                  Text('$pctv% • ${st['n']}', style: TextStyle(fontSize: 11.5, color: Colors.grey.shade600)),
                ]),
              ]),
            );
          }),
        ]),
      )),
      Card(child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('أكتر أسئلة الطلبة غلطوا فيها', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 8),
          if (missed.isEmpty) Text('مفيش بيانات كفاية.', style: TextStyle(color: Colors.grey.shade600)),
          ...missed.take(3).map((m) {
            final qt = (m['q']['text'] ?? '').toString();
            return ListTile(
              dense: true, contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.error_outline, color: Colors.red.shade300),
              title: Text(qt.length > 70 ? '${qt.substring(0, 69)}…' : qt, style: const TextStyle(fontSize: 13)),
              trailing: Text('${m['pct']}% صح', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
            );
          }),
        ]),
      )),
    ]);
  }

  Widget _stat(String label, String v) => Expanded(
        child: Card(
          margin: const EdgeInsets.all(3),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Column(children: [
              Text(v, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: kNavy)),
              Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
            ]),
          ),
        ),
      );
}
