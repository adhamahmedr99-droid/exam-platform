import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../src/core.dart';

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  List _subs = [];
  List _students = [];
  Map<String, Map<String, num>> _gmap = {};
  Map<String, List> _examQuestions = {};
  final Map<String, TextEditingController> _phones = {};
  final Set<String> _open = {};
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final subs = await sb.from('submissions')
          .select('*, exam_sessions(code_id, codes(student_name, parent_phone, exam_id, exams(id,title,subject,grade,pass_pct)))')
          .order('submitted_at', ascending: false);
      final st = await sb.from('students').select('name,parent_phone');
      final grades = await sb.from('essay_grades').select('*');
      final gmap = <String, Map<String, num>>{};
      for (final g in grades) {
        gmap.putIfAbsent(g['submission_id'] as String, () => {})[g['question_id'] as String] = g['awarded'] as num;
      }
      final qmap = <String, List>{};
      final examIds = <String>{};
      for (final s in subs) {
        final ex = s['exam_sessions']?['codes']?['exams'];
        if (ex != null) examIds.add(ex['id'] as String);
      }
      for (final id in examIds) {
        qmap[id] = await sb.from('questions').select('id,text,type,points').eq('exam_id', id).order('ord');
      }
      if (mounted) setState(() { _subs = subs; _students = st; _gmap = gmap; _examQuestions = qmap; _loading = false; });
    } catch (_) { if (mounted) { setState(() => _loading = false); toast(context, 'حصلت مشكلة في التحميل', err: true); } }
  }

  Map<String, dynamic> _report(Map s) {
    final codes = s['exam_sessions']?['codes'] ?? {};
    final ex = codes['exams'] ?? {};
    final qs = _examQuestions[ex['id']] ?? [];
    final essays = qs.where((q) => q['type'] == 'essay').toList();
    final essayMax = essays.fold<num>(0, (a, q) => a + (q['points'] as num));
    final gm = _gmap[s['id']] ?? {};
    final awarded = gm.values.fold<num>(0, (a, b) => a + b);
    final pending = essays.isNotEmpty && essays.any((q) => !gm.containsKey(q['id']));
    final score = (s['auto_score'] as num) + awarded;
    final total = (s['auto_total'] as num) + essayMax;
    final pct = total == 0 ? 0.0 : (score * 1000 / total).round() / 10;
    final wrong = <String>[];
    final auto = qs.where((q) => q['type'] != 'essay').toList();
    final bitmap = (s['bitmap'] ?? '') as String;
    for (var i = 0; i < auto.length && i < bitmap.length; i++) {
      if (bitmap[i] == '0') wrong.add(auto[i]['text'].toString());
    }
    final level = pct >= 85 ? 'ممتاز' : pct >= 75 ? 'جيد جدًا' : pct >= 65 ? 'جيد' : pct >= 50 ? 'مقبول' : 'ضعيف - يحتاج دعم';
    final passPct = ex['pass_pct'] ?? 50;
    final date = DateTime.tryParse(s['submitted_at'] ?? '')?.toLocal();
    final lines = <String>[
      'تقرير أداء الطالب: ${codes['student_name'] ?? ''}',
      'الامتحان: ${ex['title'] ?? ''}${(ex['subject'] ?? '').toString().isNotEmpty ? ' (${ex['subject']})' : ''}',
      if ((ex['grade'] ?? '').toString().isNotEmpty) 'الصف: ${ex['grade']}',
      'التاريخ: ${date == null ? '' : '${date.day}/${date.month}/${date.year}'} - الوقت المستغرق: ${((s['time_sec'] as num) / 60).round()} دقيقة',
      'الدرجة: $score من $total ($pct%)${pending ? ' - مبدئية، في انتظار تصحيح المقالي' : ''}',
      'التقدير: $level${pct >= passPct ? ' - ناجح' : ' - لم يصل لدرجة النجاح ($passPct%)'}',
      'إجابات صحيحة: ${s['correct_count']} - خاطئة أو بدون إجابة: ${(s['n_auto'] as num) - (s['correct_count'] as num)}',
      wrong.isNotEmpty ? 'محتاج يراجع: ${wrong.take(3).join(' | ')}' : 'مفيش نقاط ضعف واضحة في الأسئلة الموضوعية.',
    ];
    return {'text': lines.join('\n'), 'pct': pct, 'pending': pending};
  }

  String _phoneFor(Map s) {
    final codes = s['exam_sessions']?['codes'] ?? {};
    final name = codes['student_name'] ?? '';
    final match = _students.firstWhere((x) => x['name'] == name, orElse: () => null);
    return (match?['parent_phone'] ?? codes['parent_phone'] ?? '').toString();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تقارير أولياء الأمور')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _subs.isEmpty
                ? Center(child: Text('مفيش نتايج لسه.', style: TextStyle(color: Colors.grey.shade600)))
                : ListView(padding: const EdgeInsets.all(16), children: [
                    Card(
                      color: kGold.withOpacity(0.12),
                      child: const Padding(
                        padding: EdgeInsets.all(12),
                        child: Text('راجع التقرير واضغط «إرسال واتساب» - هيتفتح واتساب بالتقرير جاهز لولي الأمر. الإرسال بضغطة منك بعد المراجعة، مش أوتوماتيك.',
                            style: TextStyle(fontSize: 12.5, height: 1.5)),
                      ),
                    ),
                    ..._subs.map((s) {
                      final codes = s['exam_sessions']?['codes'] ?? {};
                      final ex = codes['exams'] ?? {};
                      final r = _report(s);
                      _phones.putIfAbsent(s['id'], () => TextEditingController(text: _phoneFor(s)));
                      final isOpen = _open.contains(s['id']);
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            Row(children: [
                              Expanded(child: Text(codes['student_name'] ?? '—', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5))),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(color: (r['pending'] == true ? kGold : kTeal).withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                                child: Text(r['pending'] == true ? 'مبدئي' : 'نهائي',
                                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: r['pending'] == true ? kGold : kTeal)),
                              ),
                            ]),
                            Text('${ex['title'] ?? ''} • ${r['pct']}%', style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                            if (isOpen) ...[
                              const SizedBox(height: 8),
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(color: kBg, borderRadius: BorderRadius.circular(12)),
                                child: SelectableText(r['text'], style: const TextStyle(fontSize: 13, height: 1.7)),
                              ),
                            ],
                            const SizedBox(height: 8),
                            TextField(
                              controller: _phones[s['id']],
                              keyboardType: TextInputType.phone,
                              textDirection: TextDirection.ltr,
                              textAlign: TextAlign.left,
                              decoration: const InputDecoration(labelText: 'رقم واتساب ولي الأمر', isDense: true),
                            ),
                            const SizedBox(height: 8),
                            Row(children: [
                              Expanded(child: OutlinedButton.icon(
                                onPressed: () => setState(() => isOpen ? _open.remove(s['id']) : _open.add(s['id'])),
                                icon: Icon(isOpen ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 18),
                                label: Text(isOpen ? 'إخفاء' : 'عرض التقرير', style: const TextStyle(fontSize: 13)),
                              )),
                              const SizedBox(width: 8),
                              Expanded(child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(42)),
                                onPressed: () {
                                  final ph = _phones[s['id']]!.text.trim();
                                  if (ph.isEmpty) { toast(context, 'اكتب رقم ولي الأمر الأول', err: true); return; }
                                  launchUrl(waLink(ph, r['text']), mode: LaunchMode.externalApplication);
                                },
                                icon: const Icon(Icons.send, size: 18),
                                label: const Text('إرسال واتساب', style: TextStyle(fontSize: 13)),
                              )),
                            ]),
                          ]),
                        ),
                      );
                    }),
                  ]),
      ),
    );
  }
}
