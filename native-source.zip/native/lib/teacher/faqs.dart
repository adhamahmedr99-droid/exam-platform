import 'package:flutter/material.dart';
import '../src/core.dart';

class FaqsPage extends StatefulWidget {
  const FaqsPage({super.key});
  @override
  State<FaqsPage> createState() => _FaqsPageState();
}

class _FaqsPageState extends State<FaqsPage> {
  List _faqs = [];
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await sb.from('faqs').select().order('created_at');
      if (mounted) setState(() { _faqs = r; _loading = false; });
    } catch (_) { if (mounted) { setState(() => _loading = false); toast(context, 'حصلت مشكلة في التحميل', err: true); } }
  }

  Future<void> _add() async {
    final q = TextEditingController();
    final a = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('سؤال متكرر جديد'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: q, maxLines: 2, decoration: const InputDecoration(labelText: 'السؤال *')),
            const SizedBox(height: 10),
            TextField(controller: a, maxLines: 4, decoration: const InputDecoration(labelText: 'الإجابة *')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('أضف')),
          ],
        ),
      ),
    );
    if (ok != true || q.text.trim().isEmpty || a.text.trim().isEmpty) return;
    try {
      await sb.from('faqs').insert({'teacher_id': sb.auth.currentUser!.id, 'question': q.text.trim(), 'answer': a.text.trim()});
      _load();
      if (mounted) toast(context, 'السؤال اتضاف للبوت');
    } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }

  Future<void> _delete(String id) async {
    try { await sb.from('faqs').delete().eq('id', id); _load(); } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('بوت الأسئلة المتكررة')),
        floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add_comment_outlined), label: const Text('سؤال جديد')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _faqs.isEmpty
                ? Center(child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('البوت لسه فاضي. ضيف الأسئلة اللي الطلبة بتسألها كتير وإجاباتها، والبوت هيرد بيها في تطبيق الطلبة.',
                        textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600))))
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: _faqs.length,
                      itemBuilder: (_, i) {
                        final f = _faqs[i];
                        return Card(
                          child: ListTile(
                            leading: CircleAvatar(backgroundColor: kTeal.withOpacity(0.15), child: const Icon(Icons.smart_toy_outlined, color: kNavy)),
                            title: Text(f['question'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text(f['answer'] ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
                            trailing: IconButton(icon: Icon(Icons.delete_outline, color: Colors.red.shade400), onPressed: () => _delete(f['id'])),
                          ),
                        );
                      },
                    ),
                  ),
      ),
    );
  }
}
