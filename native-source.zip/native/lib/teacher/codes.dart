import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../src/core.dart';

class CodesPage extends StatefulWidget {
  const CodesPage({super.key});
  @override
  State<CodesPage> createState() => _CodesPageState();
}

class _CodesPageState extends State<CodesPage> {
  List _exams = [];
  Map? _exam;
  List _codes = [];
  List _students = [];
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() { super.initState(); _loadExams(); }

  Future<void> _loadExams() async {
    setState(() => _loading = true);
    try {
      final e = await sb.from('exams').select('id,title,published,open_enabled,open_token').order('created_at', ascending: false);
      final st = await sb.from('students').select('*').order('name');
      if (!mounted) return;
      setState(() { _exams = e; _students = st; _exam = e.isEmpty ? null : e.first; });
      await _loadCodes();
    } catch (_) { if (mounted) { setState(() => _loading = false); toast(context, 'حصلت مشكلة في التحميل', err: true); } }
  }

  Future<void> _loadCodes() async {
    if (_exam == null) { if (mounted) setState(() => _loading = false); return; }
    try {
      final c = await sb.rpc('exam_code_status', params: {'p_exam': _exam!['id']});
      if (mounted) setState(() { _codes = c; _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  String _chipFor(String? s) => s == 'completed' ? 'مكتمل' : s == 'in_progress' ? 'قيد الحل دلوقتي' : 'غير مستخدم';
  Color _chipColor(String? s) => s == 'completed' ? kTeal : s == 'in_progress' ? kGold : Colors.grey;

  String _invite(Map c) =>
      'أهلًا ${c['student_name']}، ده الكود بتاعك لامتحان "${_exam!['title']}". افتح اللينك ده واكتب الكود عشان تبدأ: $kSiteUrl\n\nالكود: ${c['token']}';

  Future<void> _publish() async {
    setState(() => _busy = true);
    try {
      await sb.from('exams').update({'published': true}).eq('id', _exam!['id']);
      await _loadExams();
      if (mounted) { setState(() { _exam = _exams.firstWhere((e) => e['id'] == _exam!['id'], orElse: () => _exam!); }); toast(context, 'الامتحان اتنشر'); }
    } catch (_) { if (mounted) toast(context, 'النشر متمش، جرب تاني', err: true); }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _genFromNames() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('أسماء الطلبة'),
          content: TextField(controller: ctrl, maxLines: 6, decoration: const InputDecoration(hintText: 'كل اسم في سطر', border: OutlineInputBorder())),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('اعمل الأكواد')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final names = ctrl.text.split('\n').map((s) => s.trim()).where((s) => s.isNotEmpty && !_codes.any((c) => c['student_name'] == s)).toList();
    await _gen(names);
  }

  Future<void> _genForRegistered() async {
    final names = _students.map((s) => s['name'].toString()).where((n) => !_codes.any((c) => c['student_name'] == n)).toList();
    await _gen(names);
  }

  Future<void> _gen(List<String> names) async {
    if (names.isEmpty) { toast(context, 'مفيش أسماء جديدة تتعملها أكواد', err: true); return; }
    setState(() => _busy = true);
    try {
      final rows = names.map((n) => {
            'exam_id': _exam!['id'], 'student_name': n, 'token': newToken(),
            'student_id': _students.firstWhere((s) => s['name'] == n, orElse: () => {'id': null})['id'],
          }).toList();
      await sb.from('codes').insert(rows);
      await _loadCodes();
      if (mounted) toast(context, 'اتعمل ${names.length} كود');
    } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _openLink(String action) async {
    try {
      if (action == 'enable') {
        await sb.from('exams').update({'open_enabled': true, 'open_token': _exam!['open_token'] ?? newToken()}).eq('id', _exam!['id']);
      } else if (action == 'disable') {
        await sb.from('exams').update({'open_enabled': false}).eq('id', _exam!['id']);
      } else {
        await sb.from('exams').update({'open_token': newToken()}).eq('id', _exam!['id']);
      }
      await _loadExams();
      if (mounted) setState(() { _exam = _exams.firstWhere((e) => e['id'] == _exam!['id'], orElse: () => _exam!); });
    } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }

  @override
  Widget build(BuildContext context) {
    final openEnabled = _exam?['open_enabled'] == true;
    final openLink = '$kSiteUrl?open=${_exam?['open_token'] ?? ''}';
    final waText = 'لينك امتحان "${_exam?['title'] ?? ''}": افتح اللينك، اكتب اسمك، وابدأ على طول: $openLink';
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('أكواد الطلبة')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _exam == null
                ? Center(child: Text('اعمل امتحان الأول من صفحة الامتحانات.', style: TextStyle(color: Colors.grey.shade600)))
                : RefreshIndicator(
                    onRefresh: _loadExams,
                    child: ListView(padding: const EdgeInsets.all(16), children: [
                      DropdownButtonFormField<String>(
                        value: _exam!['id'] as String,
                        decoration: const InputDecoration(labelText: 'الامتحان'),
                        items: _exams.map<DropdownMenuItem<String>>((e) => DropdownMenuItem(value: e['id'] as String, child: Text(e['title'] ?? ''))).toList(),
                        onChanged: (v) { setState(() { _exam = _exams.firstWhere((e) => e['id'] == v); _loading = true; }); _loadCodes(); },
                      ),
                      const SizedBox(height: 12),
                      if (_exam!['published'] != true) ...[
                        Card(child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            const Text('الامتحان ده محفوظ كمسودة. انشره الأول عشان تقدر تعمل أكواد.'),
                            const SizedBox(height: 10),
                            BusyBtn(label: '١. انشر الامتحان', busy: _busy, onTap: _publish, icon: Icons.publish),
                          ]),
                        )),
                      ] else ...[
                        Card(child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            const Text('١. اعمل الأكواد', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                            const SizedBox(height: 4),
                            Text('كل طالب ليه كود مختلف. ابعت لكل طالب دعوته بس.', style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                            const SizedBox(height: 12),
                            ElevatedButton.icon(onPressed: _busy ? null : _genFromNames, icon: const Icon(Icons.playlist_add), label: const Text('اكتب أسماء وولّد')),
                            const SizedBox(height: 8),
                            OutlinedButton.icon(onPressed: _busy ? null : _genForRegistered, icon: const Icon(Icons.groups_outlined), label: const Text('ولّد للطلبة المسجلين')),
                          ]),
                        )),
                        Card(child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            const Text('٢. أو شارك لينك مفتوح (من غير كود)', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                            const SizedBox(height: 8),
                            if (openEnabled) ...[
                              SelectableText(openLink, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12.5)),
                              const SizedBox(height: 10),
                              Row(children: [
                                Expanded(child: OutlinedButton.icon(
                                  onPressed: () { Clipboard.setData(ClipboardData(text: openLink)); toast(context, 'اللينك اتنسخ'); },
                                  icon: const Icon(Icons.copy, size: 18), label: const Text('نسخ'))),
                                const SizedBox(width: 8),
                                Expanded(child: ElevatedButton.icon(
                                  onPressed: () => launchUrl(waLink('', waText), mode: LaunchMode.externalApplication),
                                  icon: const Icon(Icons.send, size: 18), label: const Text('واتساب'))),
                              ]),
                              const SizedBox(height: 8),
                              Row(children: [
                                Expanded(child: TextButton(onPressed: () => _openLink('regen'), child: const Text('لينك جديد'))),
                                Expanded(child: TextButton(onPressed: () => _openLink('disable'), child: const Text('إيقاف اللينك', style: TextStyle(color: Colors.red)))),
                              ]),
                            ] else
                              ElevatedButton.icon(onPressed: () => _openLink('enable'), icon: const Icon(Icons.link), label: const Text('تفعيل اللينك المفتوح')),
                            const SizedBox(height: 4),
                            Text('أي حد معاه اللينك يقدر يحل، وممكن يحل أكتر من مرة.', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                          ]),
                        )),
                      ],
                      if (_codes.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        const Text('٣. ابعت الدعوة لكل طالب', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                        const SizedBox(height: 6),
                        ..._codes.map((c) => Card(
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                                  Row(children: [
                                    Expanded(child: Text(c['student_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700))),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(color: _chipColor(c['status']).withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                                      child: Text(_chipFor(c['status']), style: TextStyle(fontSize: 12, color: _chipColor(c['status']), fontWeight: FontWeight.w700)),
                                    ),
                                  ]),
                                  Text('كود: ${c['token']}', textDirection: TextDirection.ltr, style: TextStyle(color: Colors.grey.shade600, fontSize: 13)),
                                  const SizedBox(height: 8),
                                  Row(children: [
                                    Expanded(child: OutlinedButton.icon(
                                      onPressed: () { Clipboard.setData(ClipboardData(text: _invite(c))); toast(context, 'الدعوة اتنسخت'); },
                                      icon: const Icon(Icons.copy, size: 17), label: const Text('نسخ الدعوة', style: TextStyle(fontSize: 13)))),
                                    const SizedBox(width: 8),
                                    Expanded(child: ElevatedButton.icon(
                                      style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(42)),
                                      onPressed: () => launchUrl(Uri.parse('https://wa.me/?text=${Uri.encodeComponent(_invite(c))}'), mode: LaunchMode.externalApplication),
                                      icon: const Icon(Icons.send, size: 17), label: const Text('إرسال واتساب', style: TextStyle(fontSize: 13)))),
                                  ]),
                                ]),
                              ),
                            )),
                      ] else if (_exam!['published'] == true)
                        Padding(padding: const EdgeInsets.all(16), child: Text('مفيش أكواد لسه للامتحان ده.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600))),
                    ]),
                  ),
      ),
    );
  }
}
