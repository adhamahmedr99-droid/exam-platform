import 'package:flutter/material.dart';
import '../src/core.dart';

class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});
  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _duration = TextEditingController();
  final _pass = TextEditingController();
  bool _loading = true, _busy = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final uid = sb.auth.currentUser!.id;
      final p = await sb.from('profiles').select().eq('id', uid).maybeSingle();
      if (mounted) setState(() {
        _name.text = p?['display_name'] ?? '';
        _phone.text = p?['phone'] ?? '';
        _duration.text = '${p?['default_duration'] ?? 15}';
        _pass.text = '${p?['default_pass_pct'] ?? 50}';
        _loading = false;
      });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      final uid = sb.auth.currentUser!.id;
      await sb.from('profiles').upsert({
        'id': uid, 'display_name': _name.text.trim(), 'phone': _phone.text.trim(),
        'default_duration': int.tryParse(_duration.text) ?? 15,
        'default_pass_pct': int.tryParse(_pass.text) ?? 50,
      });
      if (mounted) toast(context, 'اتحفظ');
    } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.all(16), children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const Text('الملف الشخصي', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 12),
                    TextField(controller: _name, decoration: const InputDecoration(labelText: 'اسمك (بيظهر للطلبة)')),
                    const SizedBox(height: 12),
                    TextField(controller: _phone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, textAlign: TextAlign.left,
                        decoration: const InputDecoration(labelText: 'رقم الواتساب بتاعك')),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: TextField(controller: _duration, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'مدة افتراضية (دقيقة)'))),
                      const SizedBox(width: 12),
                      Expanded(child: TextField(controller: _pass, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'نجاح افتراضي %'))),
                    ]),
                    const SizedBox(height: 16),
                    BusyBtn(label: 'حفظ', busy: _busy, onTap: _save, icon: Icons.check),
                  ]),
                ),
              ),
              const SizedBox(height: 8),
              Card(
                child: Column(children: [
                  ListTile(
                    leading: const Icon(Icons.lock_outline),
                    title: const Text('تغيير كلمة السر'),
                    subtitle: const Text('هيتبعت لينك إعادة التعيين على إيميلك'),
                    onTap: () async {
                      final email = sb.auth.currentUser?.email;
                      if (email == null) return;
                      try {
                        await sb.auth.resetPasswordForEmail(email);
                        if (context.mounted) toast(context, 'بعنالك لينك إعادة تعيين كلمة السر على إيميلك');
                      } catch (_) { if (context.mounted) toast(context, 'حصلت مشكلة', err: true); }
                    },
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.info_outline),
                    title: const Text('عن المنصة'),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutPage(teacher: true))),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.logout, color: Colors.red),
                    title: const Text('تسجيل الخروج', style: TextStyle(color: Colors.red)),
                    onTap: () async { await sb.auth.signOut(); },
                  ),
                ]),
              ),
            ]),
    );
  }
}
