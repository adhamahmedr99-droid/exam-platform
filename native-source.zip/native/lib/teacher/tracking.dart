import 'package:flutter/material.dart';
import '../src/core.dart';

class TrackingPage extends StatefulWidget {
  const TrackingPage({super.key});
  @override
  State<TrackingPage> createState() => _TrackingPageState();
}

class _TrackingPageState extends State<TrackingPage> {
  List _exams = [];
  Map? _exam;
  List _rows = [];
  List _essays = [];
  bool _loading = true;
  DateTime _loadedAt = DateTime.now();
  String _query = '';
  String _filter = 'all';

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final exams = await sb.from('exams').select('id,title,duration_min').order('created_at', ascending: false);
      if (!mounted) return;
      if (exams.isEmpty) { setState(() { _exams = []; _exam = null; _loading = false; }); return; }
      final exam = exams.firstWhere((e) => _exam != null && e['id'] == _exam!['id'], orElse: () => exams.first);
      final codes = await sb.from('codes')
          .select('id,student_name,status,exam_sessions(id,started_at,status,submissions(id,auto_score,auto_total,time_sec,submitted_at,essay_grades(question_id,awarded)))')
          .eq('exam_id', exam['id']).order('created_at');
      final essays = await sb.from('questions').select('id,points').eq('exam_id', exam['id']).eq('type', 'essay');
      if (!mounted) return;
      setState(() { _exams = exams; _exam = exam; _rows = codes; _essays = essays; _loadedAt = DateTime.now(); _loading = false; });
    } catch (_) { if (mounted) { setState(() => _loading = false); toast(context, 'مش قادرين نحمّل المتابعة دلوقتي، جرب تاني', err: true); } }
  }

  Map<String, dynamic> _calc(Map c) {
    final sessions = (c['exam_sessions'] as List?) ?? [];
    final session = sessions.isEmpty ? null : sessions.first;
    final subs = (session?['submissions'] as List?) ?? [];
    final sub = subs.isEmpty ? null : subs.first;
    final status = (sub != null || session?['status'] == 'submitted' || c['status'] == 'completed')
        ? 'submitted'
        : (session != null || c['status'] == 'in_progress')
            ? 'in_progress'
            : 'unused';
    int? elapsed;
    if (session?['started_at'] != null) {
      elapsed = DateTime.now().difference(DateTime.parse(session!['started_at']).toLocal()).inSeconds.clamp(0, 1 << 31);
    }
    final overdue = status == 'in_progress' && elapsed != null && elapsed >= ((_exam?['duration_min'] ?? 15) as num) * 60;
    final grades = (sub?['essay_grades'] as List?) ?? [];
    final pending = sub != null && _essays.any((q) => !grades.any((g) => g['question_id'] == q['id']));
    final awarded = _essays.fold<num>(0, (s, q) {
      final g = grades.firstWhere((g) => g['question_id'] == q['id'], orElse: () => null);
      return s + ((g?['awarded'] as num?) ?? 0);
    });
    num? score, total;
    if (sub != null) {
      score = (sub['auto_score'] as num) + awarded;
      total = (sub['auto_total'] as num) + _essays.fold<num>(0, (s, q) => s + (q['points'] as num));
    }
    return {'status': status, 'elapsed': elapsed, 'overdue': overdue, 'pending': pending, 'score': score, 'total': total, 'sub': sub, 'session': session};
  }

  String _fmt(int sec) => '${sec ~/ 60}:${(sec % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final counts = {'unused': 0, 'in_progress': 0, 'submitted': 0};
    final calcRows = _rows.map((c) => {...c, '_c': _calc(c)}).toList();
    for (final r in calcRows) { counts[r['_c']['status']] = (counts[r['_c']['status']] ?? 0) + 1; }
    final filtered = calcRows.where((r) {
      final st = r['_c']['status'];
      return (_filter == 'all' || st == _filter) && (r['student_name'] ?? '').toString().contains(_query);
    }).toList();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('متابعة الطلبة'), actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load)]),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _exam == null
                ? Center(child: Text('مفيش امتحانات لسه. اعمل امتحان ووزّع الأكواد، والمتابعة هتظهر هنا.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600)))
                : ListView(padding: const EdgeInsets.all(16), children: [
                    DropdownButtonFormField<String>(
                      value: _exam!['id'] as String,
                      decoration: const InputDecoration(labelText: 'اختار الامتحان'),
                      items: _exams.map<DropdownMenuItem<String>>((e) => DropdownMenuItem(value: e['id'] as String, child: Text(e['title'] ?? ''))).toList(),
                      onChanged: (v) { setState(() => _exam = _exams.firstWhere((e) => e['id'] == v)); _load(); },
                    ),
                    const SizedBox(height: 10),
                    Row(children: [
                      _count('كل الطلبة', calcRows.length, kNavy),
                      _count('لسه مدخلوش', counts['unused']!, Colors.grey),
                      _count('بيحلوا', counts['in_progress']!, kGold),
                      _count('سلّموا', counts['submitted']!, kTeal),
                    ]),
                    const SizedBox(height: 10),
                    TextField(
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'دور باسم الطالب'),
                      onChanged: (v) => setState(() => _query = v.trim()),
                    ),
                    const SizedBox(height: 8),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(children: [
                        _fchip('all', 'كل الحالات'), _fchip('unused', 'لسه مدخلوش'), _fchip('in_progress', 'دخلوا ولم يسلّموا'), _fchip('submitted', 'سلّموا'),
                      ]),
                    ),
                    const SizedBox(height: 8),
                    if (filtered.isEmpty)
                      Padding(padding: const EdgeInsets.all(24), child: Text('مفيش طلبة مطابقين.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600))),
                    ...filtered.map((r) {
                      final c = r['_c'] as Map<String, dynamic>;
                      final st = c['status'];
                      final chipColor = st == 'submitted' ? kTeal : st == 'in_progress' ? kGold : Colors.grey;
                      final chipText = st == 'submitted' ? 'سلّم الامتحان' : st == 'in_progress' ? 'دخل ولم يسلّم' : 'لسه مدخلش';
                      String detail = '';
                      if (st == 'in_progress' && c['elapsed'] != null) detail = 'بيحل من ${_fmt(c['elapsed'])} دقيقة${c['overdue'] == true ? ' • عدّى الوقت' : ''}';
                      if (st == 'submitted' && c['sub'] != null) {
                        detail = 'الدرجة: ${c['score']}/${c['total']} • الوقت: ${_fmt((c['sub']['time_sec'] as num).toInt())}${c['pending'] == true ? ' • مبدئية (مقالي مستني)' : ''}';
                      }
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: chipColor.withOpacity(0.15),
                            child: Icon(st == 'submitted' ? Icons.check : st == 'in_progress' ? Icons.edit_outlined : Icons.hourglass_empty, color: chipColor, size: 20),
                          ),
                          title: Text(r['student_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: detail.isEmpty ? null : Text(detail, style: const TextStyle(fontSize: 12.5)),
                          trailing: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(color: chipColor.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                            child: Text(chipText, style: TextStyle(fontSize: 11.5, color: chipColor, fontWeight: FontWeight.w700)),
                          ),
                        ),
                      );
                    }),
                    const SizedBox(height: 10),
                    Text('«دخل ولم يسلّم» معناها إنه بدأ جلسة، مش بالضرورة فاتح دلوقتي. لو في أسئلة مقالية، الدرجة مبدئية لحد تصحيحها.',
                        style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
                  ]),
      ),
    );
  }

  Widget _count(String label, int v, Color color) => Expanded(
        child: Card(
          margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 4),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Column(children: [
              Text('$v', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: color)),
              Text(label, style: TextStyle(fontSize: 10.5, color: Colors.grey.shade600), textAlign: TextAlign.center),
            ]),
          ),
        ),
      );

  Widget _fchip(String v, String label) => Padding(
        padding: const EdgeInsets.only(left: 6),
        child: ChoiceChip(label: Text(label), selected: _filter == v, onSelected: (_) => setState(() => _filter = v)),
      );
}
