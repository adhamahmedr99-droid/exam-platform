import 'package:flutter/material.dart';
import '../src/core.dart';

class ResultsPage extends StatefulWidget {
  const ResultsPage({super.key});
  @override
  State<ResultsPage> createState() => _ResultsPageState();
}

class _ResultsPageState extends State<ResultsPage> {
  List _subs = [];
  Map<String, Map<String, num>> _gmap = {};
  Map<String, List> _examQuestions = {};
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final subs = await sb.from('submissions')
          .select('*, exam_sessions(code_id, codes(token, student_name, parent_phone, exam_id, exams(id,title,subject,grade,pass_pct)))')
          .order('submitted_at', ascending: false);
      final grades = await sb.from('essay_grades').select('*');
      final gmap = <String, Map<String, num>>{};
      for (final g in grades) {
        gmap.putIfAbsent(g['submission_id'] as String, () => {})[g['question_id'] as String] = g['awarded'] as num;
      }
      final examIds = <String>{};
      for (final s in subs) {
        final ex = s['exam_sessions']?['codes']?['exams'];
        if (ex != null) examIds.add(ex['id'] as String);
      }
      final qmap = <String, List>{};
      for (final id in examIds) {
        qmap[id] = await sb.from('questions').select('id,text,type,points').eq('exam_id', id).order('ord');
      }
      if (mounted) setState(() { _subs = subs; _gmap = gmap; _examQuestions = qmap; _loading = false; });
    } catch (_) { if (mounted) { setState(() => _loading = false); toast(context, 'حصلت مشكلة في التحميل', err: true); } }
  }

  Map<String, dynamic> _calc(Map s) {
    final ex = s['exam_sessions']?['codes']?['exams'] ?? {};
    final qs = _examQuestions[ex['id']] ?? [];
    final essays = qs.where((q) => q['type'] == 'essay').toList();
    final essayMax = essays.fold<num>(0, (a, q) => a + (q['points'] as num));
    final gm = _gmap[s['id']] ?? {};
    final awarded = gm.values.fold<num>(0, (a, b) => a + b);
    final pending = essays.isNotEmpty && essays.any((q) => !gm.containsKey(q['id']));
    final score = (s['auto_score'] as num) + awarded;
    final total = (s['auto_total'] as num) + essayMax;
    final pct = total == 0 ? 0 : (score / total * 1000).round() / 10;
    return {'score': score, 'total': total, 'pct': pct, 'pending': pending, 'passPct': ex['pass_pct'] ?? 50};
  }

  Future<void> _deleteSub(Map s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('حذف النتيجة؟'),
          content: Text('هتمسح نتيجة ${s['exam_sessions']?['codes']?['student_name'] ?? ''} نهائيًا.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لأ')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('أيوه، احذف')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try { await sb.from('submissions').delete().eq('id', s['id']); _load(); } catch (_) { if (mounted) toast(context, 'حصلت مشكلة', err: true); }
  }

  Future<void> _gradeEssays(Map s) async {
    final ex = s['exam_sessions']?['codes']?['exams'] ?? {};
    final qs = (_examQuestions[ex['id']] ?? []).where((q) => q['type'] == 'essay').toList();
    if (qs.isEmpty) { toast(context, 'الامتحان ده مفيهوش أسئلة مقالية'); return; }
    final ans = await sb.from('answers').select('*').eq('session_id', s['session_id']);
    final amap = {for (final a in ans) a['question_id'] as String: a['answer']};
    final gm = _gmap[s['id']] ?? {};
    if (!mounted) return;
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: EssayGradeSheet(submissionId: s['id'], questions: qs, answers: amap, grades: gm),
        ),
      ),
    );
    if (saved == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('النتايج وتصحيح المقالي')),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _subs.isEmpty
                ? Center(child: Text('مفيش نتايج لسه. أول ما الطلبة يسلّموا هتظهر هنا.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600)))
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: _subs.length,
                      itemBuilder: (_, i) {
                        final s = _subs[i];
                        final c = _calc(s);
                        final codes = s['exam_sessions']?['codes'] ?? {};
                        final ex = codes['exams'] ?? {};
                        final passed = (c['pct'] as num) >= (c['passPct'] as num);
                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                              Row(children: [
                                Expanded(child: Text(codes['student_name'] ?? '—', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15.5))),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(color: (c['pending'] == true ? kGold : (passed ? kTeal : Colors.red)).withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
                                  child: Text(c['pending'] == true ? 'مبدئي' : (passed ? 'ناجح' : 'راسب'),
                                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: c['pending'] == true ? kGold : (passed ? kTeal : Colors.red))),
                                ),
                              ]),
                              const SizedBox(height: 4),
                              Text('${ex['title'] ?? ''} • تلقائي: ${s['auto_score']}/${s['auto_total']} • صح ${s['correct_count']} من ${s['n_auto']}',
                                  style: TextStyle(color: Colors.grey.shade600, fontSize: 12.5)),
                              Text('النهائي: ${c['score']}/${c['total']} (${c['pct']}%) • ${((s['time_sec'] as num) / 60).round()} دقيقة',
                                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
                              const SizedBox(height: 8),
                              Row(children: [
                                Expanded(child: OutlinedButton.icon(onPressed: () => _gradeEssays(s), icon: const Icon(Icons.rate_review_outlined, size: 18), label: const Text('المقالي', style: TextStyle(fontSize: 13)))),
                                const SizedBox(width: 8),
                                IconButton(icon: Icon(Icons.delete_outline, color: Colors.red.shade400), onPressed: () => _deleteSub(s)),
                              ]),
                            ]),
                          ),
                        );
                      },
                    ),
                  ),
      ),
    );
  }
}

class EssayGradeSheet extends StatefulWidget {
  final String submissionId;
  final List questions;
  final Map<String, dynamic> answers;
  final Map<String, num> grades;
  const EssayGradeSheet({super.key, required this.submissionId, required this.questions, required this.answers, required this.grades});
  @override
  State<EssayGradeSheet> createState() => _EssayGradeSheetState();
}

class _EssayGradeSheetState extends State<EssayGradeSheet> {
  final _ctrls = <String, TextEditingController>{};
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    for (final q in widget.questions) {
      _ctrls[q['id']] = TextEditingController(text: widget.grades[q['id']]?.toString() ?? '');
    }
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      for (final q in widget.questions) {
        final t = _ctrls[q['id']]!.text.trim();
        if (t.isEmpty) continue;
        final max = (q['points'] as num).toDouble();
        final v = (double.tryParse(t) ?? 0).clamp(0, max);
        await sb.from('essay_grades').upsert({'submission_id': widget.submissionId, 'question_id': q['id'], 'awarded': v});
      }
      if (mounted) { Navigator.pop(context, true); toast(context, 'التصحيح اتحفظ'); }
    } catch (_) { if (mounted) { setState(() => _busy = false); toast(context, 'حصلت مشكلة', err: true); } }
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false, initialChildSize: 0.85, maxChildSize: 0.95,
      builder: (_, sc) => ListView(controller: sc, padding: const EdgeInsets.all(20), children: [
        const Text('تصحيح المقالي', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
        const SizedBox(height: 12),
        ...widget.questions.map((q) {
          final ans = widget.answers[q['id']];
          String ansText = '(الطالب مكتبش إجابة)';
          if (ans != null) {
            ansText = ans is String ? ans : (ans['text'] ?? ans.toString());
          }
          return Card(
            color: kBg,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text('${q['text']} (من ${q['points']})', style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                  child: Text(ansText, style: TextStyle(color: Colors.grey.shade800, height: 1.5)),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _ctrls[q['id']],
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(labelText: 'الدرجة (حد أقصى ${q['points']})'),
                ),
              ]),
            ),
          );
        }),
        const SizedBox(height: 10),
        BusyBtn(label: 'احفظ التصحيح', busy: _busy, onTap: _save, icon: Icons.save_outlined),
      ]),
    );
  }
}
