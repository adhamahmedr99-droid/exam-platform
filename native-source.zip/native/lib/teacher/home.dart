import 'package:flutter/material.dart';
import '../src/core.dart';
import 'exams.dart';
import 'videos.dart';
import 'settings.dart';
import 'students.dart';
import 'codes.dart';
import 'tracking.dart';
import 'results.dart';
import 'analytics.dart';
import 'reports.dart';
import 'faqs.dart';

class TeacherHome extends StatefulWidget {
  const TeacherHome({super.key});
  @override
  State<TeacherHome> createState() => _TeacherHomeState();
}

class _TeacherHomeState extends State<TeacherHome> {
  int _tab = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const DashboardTab(), const ExamsTab(), const VideosTab(), const MoreTab()];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: pages[_tab],
        bottomNavigationBar: NavigationBar(
          selectedIndex: _tab,
          onDestinationSelected: (i) => setState(() => _tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'الامتحانات'),
            NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'الفيديوهات'),
            NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'المزيد'),
          ],
        ),
      ),
    );
  }
}

class DashboardTab extends StatefulWidget {
  const DashboardTab({super.key});
  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  Map<String, int> _stats = {};
  List _recent = [];
  String _name = '';
  bool _loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final uid = sb.auth.currentUser!.id;
      final prof = await sb.from('profiles').select().eq('id', uid).maybeSingle();
      final exams = await sb.from('exams').select('id').eq('teacher_id', uid).count();
      final students = await sb.from('students').select('id').eq('teacher_id', uid).count();
      final subs = await sb.from('video_students').select('id').eq('teacher_id', uid).eq('active', true).count();
      final recentExams = await sb.from('exams').select('id, title, subject, published, created_at').eq('teacher_id', uid).order('created_at', ascending: false).limit(5);
      // attempts count: codes joined via exams
      int attempts = 0;
      final exIds = (recentExams as List).map((e) => e['id']).toList();
      if (exIds.isNotEmpty) {
        final c = await sb.from('codes').select('id').inFilter('exam_id', exIds).count();
        attempts = c.count;
      }
      if (mounted) setState(() {
        _name = (prof?['display_name'] ?? '') as String;
        _stats = {'exams': exams.count, 'students': students.count, 'subs': subs.count, 'attempts': attempts};
        _recent = recentExams;
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التحكم')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Text(_name.isEmpty ? 'أهلًا بيك يا مستر 👋' : 'أهلًا بيك يا مستر $_name 👋',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          if (_loading) const Center(child: Padding(padding: EdgeInsets.all(40), child: CircularProgressIndicator()))
          else ...[
            GridView.count(
              crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.6,
              children: [
                _stat('الامتحانات', _stats['exams'] ?? 0, Icons.assignment, kNavy),
                _stat('الطلبة', _stats['students'] ?? 0, Icons.school, kTeal),
                _stat('محاولات (آخر ٥ امتحانات)', _stats['attempts'] ?? 0, Icons.edit_note, kGold),
                _stat('مشتركي الفيديو', _stats['subs'] ?? 0, Icons.play_circle, Colors.purple),
              ],
            ),
            const SizedBox(height: 16),
            const Text('أحدث الامتحانات', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            if (_recent.isEmpty)
              Card(child: Padding(padding: const EdgeInsets.all(24), child: Text('مفيش امتحانات لسه. اعمل أول امتحان من تاب الامتحانات.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600))))
            else
              ..._recent.map((e) => Card(
                    child: ListTile(
                      leading: Icon(Icons.assignment, color: e['published'] == true ? kTeal : Colors.grey),
                      title: Text(e['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${e['subject'] ?? ''} • ${e['published'] == true ? 'منشور' : 'مسودة'}'),
                    ),
                  )),
          ],
        ]),
      ),
    );
  }

  Widget _stat(String label, int v, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, color: color, size: 26),
          const SizedBox(height: 6),
          Text('$v', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          Text(label, style: TextStyle(fontSize: 11.5, color: Colors.grey.shade600), textAlign: TextAlign.center),
        ]),
      ),
    );
  }
}

class MoreTab extends StatelessWidget {
  const MoreTab({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <(String, IconData, Widget)>[
      ('الطلبة', Icons.groups_outlined, const StudentsPage()),
      ('أكواد الطلبة', Icons.key_outlined, const CodesPage()),
      ('متابعة الطلبة', Icons.track_changes, const TrackingPage()),
      ('النتايج وتصحيح المقالي', Icons.fact_check_outlined, const ResultsPage()),
      ('التحليلات', Icons.bar_chart, const AnalyticsPage()),
      ('تقارير أولياء الأمور', Icons.assignment_ind_outlined, const ReportsPage()),
      ('بوت الأسئلة المتكررة', Icons.smart_toy_outlined, const FaqsPage()),
      ('الإعدادات', Icons.settings_outlined, const SettingsTab()),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('المزيد')),
        body: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: items.length,
          itemBuilder: (_, i) {
            final it = items[i];
            return Card(
              child: ListTile(
                leading: CircleAvatar(backgroundColor: kNavy.withOpacity(0.08), child: Icon(it.$2, color: kNavy)),
                title: Text(it.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
                trailing: const Icon(Icons.chevron_left),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => it.$3)),
              ),
            );
          },
        ),
      ),
    );
  }
}
