import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../src/core.dart';

class TeacherLoginPage extends StatefulWidget {
  final VoidCallback onLoggedIn;
  const TeacherLoginPage({super.key, required this.onLoggedIn});
  @override
  State<TeacherLoginPage> createState() => _TeacherLoginPageState();
}

class _TeacherLoginPageState extends State<TeacherLoginPage> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;
  bool _signupMode = false;

  Future<void> _submit() async {
    final email = _email.text.trim(), pass = _pass.text;
    if (email.isEmpty || pass.isEmpty) { toast(context, 'اكتب الإيميل وكلمة السر', err: true); return; }
    setState(() => _busy = true);
    try {
      if (_signupMode) {
        await sb.auth.signUp(email: email, password: pass);
        if (mounted) toast(context, 'الحساب اتعمل. سجّل دخول دلوقتي بنفس الإيميل وكلمة السر.');
        setState(() => _signupMode = false);
      } else {
        await sb.auth.signInWithPassword(email: email, password: pass);
        widget.onLoggedIn();
      }
    } on AuthException catch (e) {
      if (mounted) toast(context, _signupMode ? 'مشكلة في إنشاء الحساب: ${e.message}' : 'الإيميل أو كلمة السر مش مظبوطين', err: true);
    } catch (_) {
      if (mounted) toast(context, 'حصلت مشكلة، جرب تاني', err: true);
    }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _forgot() async {
    final email = _email.text.trim();
    if (email.isEmpty) { toast(context, 'اكتب إيميلك الأول وبعدين دوس نسيت كلمة السر', err: true); return; }
    setState(() => _busy = true);
    try {
      await sb.auth.resetPasswordForEmail(email);
      if (mounted) toast(context, 'بعنالك لينك إعادة تعيين كلمة السر على إيميلك');
    } catch (_) {
      if (mounted) toast(context, 'حصلت مشكلة، جرب تاني', err: true);
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(children: [
            FadeSlideIn(child: const BrandHeader(subtitle: 'امتحانات وفيديوهات شرح طلبتك في مكان واحد')),
            Padding(
              padding: const EdgeInsets.all(20),
              child: FadeSlideIn(
                delayMs: 200,
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Text(_signupMode ? 'حساب مدرس جديد' : 'دخول المدرس',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
                      const SizedBox(height: 6),
                      Text('كل مدرس ليه حسابه الخاص: امتحاناته وطلبته ودرجاتهم منفصلة تمامًا.',
                          style: TextStyle(color: Colors.grey.shade600, fontSize: 13), textAlign: TextAlign.center),
                      const SizedBox(height: 20),
                      TextField(
                        controller: _email,
                        keyboardType: TextInputType.emailAddress,
                        textDirection: TextDirection.ltr,
                        textAlign: TextAlign.left,
                        decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.mail_outline)),
                      ),
                      const SizedBox(height: 12),
                      PwField(controller: _pass, action: TextInputAction.done, onSubmit: (_) => _submit()),
                      Align(
                        alignment: AlignmentDirectional.centerStart,
                        child: TextButton(onPressed: _busy ? null : _forgot, child: const Text('نسيت كلمة السر؟')),
                      ),
                      BusyBtn(label: _signupMode ? 'إنشاء الحساب' : 'دخول', busy: _busy, onTap: _submit, icon: Icons.login),
                      TextButton(
                        onPressed: _busy ? null : () => setState(() => _signupMode = !_signupMode),
                        child: Text(_signupMode ? 'عندك حساب؟ سجّل دخول' : 'أول مرة؟ اعمل حساب جديد'),
                      ),
                      Text('حساب جديد بيدخل على طول من غير تأكيد إيميل.',
                          style: TextStyle(color: Colors.grey.shade500, fontSize: 12), textAlign: TextAlign.center),
                    ]),
                  ),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
