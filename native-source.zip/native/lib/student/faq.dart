import 'package:flutter/material.dart';
import '../src/core.dart';

class FaqBotPage extends StatefulWidget {
  const FaqBotPage({super.key});
  @override
  State<FaqBotPage> createState() => _FaqBotPageState();
}

class _Msg {
  final String text;
  final bool fromUser;
  const _Msg(this.text, this.fromUser);
}

class _FaqBotPageState extends State<FaqBotPage> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final List<_Msg> _msgs = [];
  List _faqs = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await sb.rpc('faq_list');
      if (mounted) {
        setState(() { _faqs = r is List ? r : []; _loading = false; });
        _msgs.add(_Msg(_faqs.isEmpty
            ? 'أهلًا بيك! 👋 أنا بوت الأسئلة المتكررة. لسه مفيش أسئلة اتعلمتها، أول ما المدرس يضيف أسئلة وأجوبة هقدر أرد عليك.'
            : 'أهلًا بيك! 👋 اسألني أي سؤال من الأسئلة المتكررة وهجاوبك على طول.', false));
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _norm(String s) => s
      .replaceAll(RegExp(r'[أإآ]'), 'ا')
      .replaceAll('ة', 'ه')
      .replaceAll('ى', 'ي')
      .replaceAll(RegExp(r'[^\u0621-\u064Aa-zA-Z0-9\s]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim()
      .toLowerCase();

  void _ask() {
    final q = _input.text.trim();
    if (q.isEmpty) return;
    _input.clear();
    setState(() => _msgs.add(_Msg(q, true)));
    final nq = _norm(q);
    final qWords = nq.split(' ').where((w) => w.length > 2).toSet();
    Map? best;
    var bestScore = 0;
    for (final f in _faqs) {
      final fq = _norm(f['question'] ?? '');
      final fWords = fq.split(' ').where((w) => w.length > 2).toSet();
      final common = qWords.intersection(fWords).length;
      final contains = fq.contains(nq) || nq.contains(fq);
      final score = common * 2 + (contains ? 5 : 0);
      if (score > bestScore) { bestScore = score; best = f; }
    }
    final answer = (best != null && bestScore >= 4)
        ? (best['answer'] ?? '').toString()
        : (_faqs.isEmpty
            ? 'لسه مفيش إجابات متسجلة. اسأل المدرس مباشرة دلوقتي.'
            : 'مش لاقي إجابة للسؤال ده عندي. جرب تسأل بطريقة تانية، أو اسأل المدرس مباشرة.');
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() => _msgs.add(_Msg(answer, false)));
        _scroll.animateTo(_scroll.position.maxScrollExtent + 120, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.smart_toy_outlined, size: 22), SizedBox(width: 6), Text('بوت الأسئلة')])),
        body: Column(children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.all(16),
                    itemCount: _msgs.length,
                    itemBuilder: (_, i) {
                      final m = _msgs[i];
                      return Align(
                        alignment: m.fromUser ? Alignment.centerLeft : Alignment.centerRight,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
                          decoration: BoxDecoration(
                            color: m.fromUser ? kNavy : Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            border: m.fromUser ? null : Border.all(color: Colors.grey.shade200),
                          ),
                          child: Text(m.text, style: TextStyle(color: m.fromUser ? Colors.white : Colors.grey.shade900, height: 1.5)),
                        ),
                      );
                    },
                  ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
              child: Row(children: [
                Expanded(
                  child: TextField(
                    controller: _input,
                    onSubmitted: (_) => _ask(),
                    decoration: const InputDecoration(hintText: 'اكتب سؤالك هنا…', isDense: true),
                  ),
                ),
                const SizedBox(width: 8),
                CircleAvatar(backgroundColor: kNavy, child: IconButton(icon: const Icon(Icons.send, color: Colors.white, size: 20), onPressed: _ask)),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
