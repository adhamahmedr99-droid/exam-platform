import 'package:flutter/material.dart';
import '../src/core.dart';
import 'exam.dart';
import 'videos.dart';

class StagesPage extends StatelessWidget {
  const StagesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('المراحل الدراسية')),
        body: GridView.count(
          crossAxisCount: 2,
          padding: const EdgeInsets.all(16),
          mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.15,
          children: kStages.asMap().entries.map((e) {
            final icons = [Icons.looks_4, Icons.looks_5, Icons.looks_6, Icons.looks_one, Icons.looks_two, Icons.looks_3];
            return Card(
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StagePage(stage: e.value))),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  CircleAvatar(backgroundColor: kNavy.withOpacity(0.08), radius: 26, child: Icon(icons[e.key], color: kNavy)),
                  const SizedBox(height: 10),
                  Text(e.value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5), textAlign: TextAlign.center),
                ]),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class StagePage extends StatefulWidget {
  final String stage;
  const StagePage({super.key, required this.stage});
  @override
  State<StagePage> createState() => _StagePageState();
}

class _StagePageState extends State<StagePage> {
  List _exams = [];
  bool _loading = true;
  int _tab = 0;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final r = await sb.rpc('public_stage_exams', params: {'p_grade': widget.stage});
      if (mounted) setState(() { _exams = r is List ? r : []; _loading = false; });
    } catch (_) { if (mounted) setState(() { _exams = []; _loading = false; }); }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.stage, style: const TextStyle(fontSize: 17))),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Row(children: [
              _tabBtn(0, 'الامتحانات', Icons.assignment_outlined),
              const SizedBox(width: 8),
              _tabBtn(1, 'الفيديوهات', Icons.play_circle_outline),
            ]),
          ),
          Expanded(child: _tab == 0 ? _examsTab() : _videosTab()),
        ]),
      ),
    );
  }

  Widget _tabBtn(int i, String label, IconData icon) {
    final sel = _tab == i;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _tab = i),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: sel ? kNavy : Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: sel ? kNavy : Colors.grey.shade300),
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 18, color: sel ? Colors.white : kNavy),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(color: sel ? Colors.white : kNavy, fontWeight: FontWeight.w700)),
          ]),
        ),
      ),
    );
  }

  Widget _examsTab() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_exams.isEmpty) {
      return Center(child: Padding(
        padding: const EdgeInsets.all(28),
        child: Text('القسم ده لسه مقفول، أول ما تتضاف امتحانات للمرحلة دي هتظهر هنا لوحدها.',
            textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600, height: 1.6)),
      ));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _exams.length,
      itemBuilder: (_, i) {
        final e = _exams[i];
        return Card(
          child: ListTile(
            leading: CircleAvatar(backgroundColor: kTeal.withOpacity(0.15), child: const Icon(Icons.assignment, color: kNavy)),
            title: Text(e['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('${e['subject'] ?? ''} • ${e['duration_min']} دقيقة${(e['teacher_name'] ?? '').toString().isNotEmpty ? ' • ${e['teacher_name']}' : ''}'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CodeEntryPage())),
          ),
        );
      },
    );
  }

  Widget _videosTab() {
    return Center(child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('فيديوهات الشرح للمشتركين بس.', style: TextStyle(color: Colors.grey.shade600)),
        const SizedBox(height: 12),
        ElevatedButton.icon(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoLoginPage(stage: widget.stage))),
          icon: const Icon(Icons.play_arrow),
          label: const Text('دخول المشتركين'),
        ),
      ]),
    ));
  }
}
