import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../src/core.dart';
import 'exam.dart';
import 'videos.dart';
import 'stages.dart';
import 'faq.dart';

class StudentLanding extends StatelessWidget {
  const StudentLanding({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SingleChildScrollView(
          child: Column(children: [
            FadeSlideIn(child: const BrandHeader(subtitle: 'خد نفس، ركّز، وحلّ على مهلك. كل سؤال خطوة لقدّام.')),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(children: [
                FadeSlideIn(
                  delayMs: 200,
                  child: _bigCard(
                    context,
                    icon: Icons.key, color: kNavy,
                    title: 'بوابة الامتحانات',
                    subtitle: 'اكتب الكود اللي المدرس بعتهولك عشان تدخل امتحانك',
                    btn: 'دخول الامتحان',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CodeEntryPage())),
                  ),
                ),
                const SizedBox(height: 12),
                FadeSlideIn(
                  delayMs: 350,
                  child: _bigCard(
                    context,
                    icon: Icons.play_circle, color: kTeal,
                    title: 'فيديوهات الشرح',
                    subtitle: 'لو اشتركت في فيديوهات الشرح، ادخل باليوزر والباسورد اللي المدرس دهوملك',
                    btn: 'دخول الفيديوهات',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VideoLoginPage())),
                  ),
                ),
                const SizedBox(height: 12),
                FadeSlideIn(
                  delayMs: 420,
                  child: _bigCard(
                    context,
                    icon: Icons.grid_view_rounded, color: kGold,
                    title: 'أقسام المراحل',
                    subtitle: 'امتحانات وفيديوهات كل مرحلة لوحدها، من رابعة ابتدائي لحد تالتة إعدادي',
                    btn: 'اختار مرحلتك',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StagesPage())),
                  ),
                ),
                const SizedBox(height: 12),
                FadeSlideIn(
                  delayMs: 460,
                  child: _bigCard(
                    context,
                    icon: Icons.smart_toy_outlined, color: kNavy2,
                    title: 'بوت الأسئلة المتكررة',
                    subtitle: 'عندك سؤال؟ اسأل البوت وهيرد عليك من الأسئلة المسجلة',
                    btn: 'اسأل البوت',
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FaqBotPage())),
                  ),
                ),
                const SizedBox(height: 12),
                FadeSlideIn(
                  delayMs: 500,
                  child: Card(
                    child: ListTile(
                      leading: const Icon(Icons.payments_outlined, color: kGold),
                      title: const Text('الاشتراك في فيديوهات الشرح', style: TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: const Text('حوّل قيمة الاشتراك فودافون كاش وخد اليوزر والباسورد من مدرسك'),
                      onTap: () => showVodafonePaySheet(context),
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.info_outline, color: kTeal),
                    title: const Text('عن المنصة', style: TextStyle(fontWeight: FontWeight.w700)),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutPage())),
                  ),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _bigCard(BuildContext context, {required IconData icon, required Color color, required String title, required String subtitle, required String btn, required VoidCallback onTap}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            CircleAvatar(backgroundColor: color.withOpacity(0.12), child: Icon(icon, color: color)),
            const SizedBox(width: 12),
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          ]),
          const SizedBox(height: 8),
          Text(subtitle, style: TextStyle(color: Colors.grey.shade600, fontSize: 13.5)),
          const SizedBox(height: 14),
          ElevatedButton(onPressed: onTap, child: Text(btn)),
        ]),
      ),
    );
  }
}

void showVodafonePaySheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('دفع الاشتراك - فودافون كاش', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text('حوّل قيمة الاشتراك على الرقم ده، وبعدها مدرسك هيديك اليوزر والباسورد:',
              style: TextStyle(color: Colors.grey.shade600), textAlign: TextAlign.center),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(color: kBg, borderRadius: BorderRadius.circular(14)),
            child: const Text(kVodafoneCashNumber, textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () { Clipboard.setData(const ClipboardData(text: kVodafoneCashNumber)); toast(ctx, 'الرقم اتنسخ'); },
            icon: const Icon(Icons.copy), label: const Text('نسخ الرقم'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => launchUrl(Uri.parse('tel:*9*7*$kVodafoneCashNumber%23')),
            icon: const Icon(Icons.dialpad), label: const Text('تحويل من الاتصال (*9#)'),
          ),
          const SizedBox(height: 8),
        ]),
      ),
    ),
  );
}
