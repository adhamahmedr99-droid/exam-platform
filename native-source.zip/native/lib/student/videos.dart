import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../src/core.dart';
import 'landing.dart' show showVodafonePaySheet;

class VideoLoginPage extends StatefulWidget {
  final String stage;
  const VideoLoginPage({super.key, this.stage = ''});
  @override
  State<VideoLoginPage> createState() => _VideoLoginPageState();
}

class _VideoLoginPageState extends State<VideoLoginPage> {
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _trySaved();
  }

  Future<void> _trySaved() async {
    final prefs = await SharedPreferences.getInstance();
    final u = prefs.getString('vuser'), p = prefs.getString('vpass');
    if (u != null && p != null && u.isNotEmpty) _login(u, p, quiet: true);
  }

  Future<void> _login(String u, String p, {bool quiet = false}) async {
    if (u.trim().isEmpty || p.isEmpty) { if (!quiet) toast(context, 'اكتب اسم المستخدم وكلمة السر', err: true); return; }
    setState(() => _busy = true);
    try {
      final r = await sb.rpc('video_login', params: {'p_username': u.trim(), 'p_password': p});
      if (!mounted) return;
      if (r['ok'] != true) {
        final m = {'invalid': 'اليوزر أو الباسورد مش مظبوطين.', 'inactive': 'الاشتراك ده متوقف حاليًا. كلم مدرسك.', 'throttled': 'محاولات كتير غلط. استنى ١٠ دقايق وجرّب تاني.'};
        if (!quiet) toast(context, m[r['error']] ?? 'حصلت مشكلة، جرب تاني', err: true);
        setState(() => _busy = false);
        return;
      }
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('vuser', u.trim());
      await prefs.setString('vpass', p);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => VideoLibraryPage(name: r['name'] ?? '', videos: r['videos'] ?? [], stage: widget.stage)));
    } catch (_) {
      if (mounted && !quiet) { toast(context, 'حصلت مشكلة في الاتصال، جرب تاني', err: true); setState(() => _busy = false); }
      else if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('فيديوهات الشرح')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          FadeSlideIn(
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const Text('دخول المشتركين', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
                  const SizedBox(height: 6),
                  Text('ادخل باليوزر والباسورد اللي المدرس دهوملك', style: TextStyle(color: Colors.grey.shade600), textAlign: TextAlign.center),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _user, textDirection: TextDirection.ltr, textAlign: TextAlign.left,
                    decoration: const InputDecoration(labelText: 'اسم المستخدم', prefixIcon: Icon(Icons.person_outline)),
                  ),
                  const SizedBox(height: 12),
                  PwField(controller: _pass, action: TextInputAction.done, onSubmit: (_) => _login(_user.text, _pass.text)),
                  const SizedBox(height: 16),
                  BusyBtn(label: 'دخول للفيديوهات', busy: _busy, onTap: () => _login(_user.text, _pass.text), icon: Icons.play_arrow),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.payments_outlined, color: kGold),
              title: const Text('لسه مش مشترك؟', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: const Text('دوس هنا عشان تدفع فودافون كاش'),
              onTap: () => showVodafonePaySheet(context),
            ),
          ),
        ]),
      ),
    );
  }
}

class VideoLibraryPage extends StatefulWidget {
  final String name;
  final List videos;
  final String stage;
  const VideoLibraryPage({super.key, required this.name, required this.videos, this.stage = ''});
  @override
  State<VideoLibraryPage> createState() => _VideoLibraryPageState();
}

class _VideoLibraryPageState extends State<VideoLibraryPage> {
  late String _filter = widget.stage;
  @override
  Widget build(BuildContext context) {
    final videos = widget.videos.where((v) => _filter.isEmpty || (v['grade'] ?? '') == _filter).toList();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('فيديوهات الشرح')),
        body: Column(children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(18),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [kNavy, kNavy2], begin: Alignment.topRight, end: Alignment.bottomLeft),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
            child: Column(children: [
              Text('أهلًا ${widget.name}! 👋', style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text('فيديوهات الشرح المتاحة ليك كلها هنا', style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 13)),
            ]),
          ),
          SizedBox(
            height: 46,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(label: const Text('كل المراحل'), selected: _filter.isEmpty, onSelected: (_) => setState(() => _filter = ''))),
                ...kStages.map((st) => Padding(padding: const EdgeInsets.only(left: 6), child: ChoiceChip(label: Text(st), selected: _filter == st, onSelected: (_) => setState(() => _filter = st)))),
              ],
            ),
          ),
          Expanded(
            child: videos.isEmpty
                ? Center(child: Text('مفيش فيديوهات متاحة ليك لسه.', style: TextStyle(color: Colors.grey.shade600)))
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: videos.length,
                    itemBuilder: (_, i) {
                      final v = videos[i];
                      final id = ytId(v['url'] ?? '');
                      return Card(
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPlayerPage(title: v['title'] ?? '', url: v['url'] ?? ''))),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            if (id.isNotEmpty)
                              Image.network('https://i.ytimg.com/vi/$id/hqdefault.jpg', height: 160, fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(height: 160, color: kNavy2, child: const Icon(Icons.play_circle, color: Colors.white54, size: 48)))
                            else
                              Container(height: 120, color: kNavy2, child: const Icon(Icons.play_circle, color: Colors.white54, size: 48)),
                            Padding(
                              padding: const EdgeInsets.all(14),
                              child: Row(children: [
                                Expanded(child: Text(v['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
                                const Icon(Icons.play_circle_fill, color: kTeal),
                              ]),
                            ),
                          ]),
                        ),
                      );
                    },
                  ),
          ),
        ]),
      ),
    );
  }
}

class VideoPlayerPage extends StatelessWidget {
  final String title;
  final String url;
  const VideoPlayerPage({super.key, required this.title, required this.url});
  @override
  Widget build(BuildContext context) {
    final yt = ytId(url);
    final dr = driveId(url);
    final embed = yt.isNotEmpty
        ? 'https://www.youtube-nocookie.com/embed/$yt?rel=0'
        : 'https://drive.google.com/file/d/$dr/preview';
    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(embed));
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis)),
        body: WebViewWidget(controller: controller),
      ),
    );
  }
}
