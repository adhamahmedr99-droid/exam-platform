import 'dart:math';
import 'dart:async';
import 'package:flutter/material.dart';
import '../src/core.dart';

class CodeEntryPage extends StatefulWidget {
  const CodeEntryPage({super.key});
  @override
  State<CodeEntryPage> createState() => _CodeEntryPageState();
}

class _CodeEntryPageState extends State<CodeEntryPage> {
  final _code = TextEditingController();
  bool _busy = false;

  Future<void> _redeem() async {
    final token = _code.text.trim().toUpperCase();
    if (token.isEmpty) { toast(context, 'اكتب الكود الأول', err: true); return; }
    setState(() => _busy = true);
    try {
      final r = await sb.rpc('redeem_code', params: {'p_token': token});
      if (!mounted) return;
      if (r['ok'] != true) {
        final m = {
          'invalid_code': 'الكود ده مش مظبوط. اتأكد منه وكلم مدرسك.',
          'not_published': 'الامتحان ده لسه مش متاح.',
          'not_yet': 'الامتحان لسه ما بدأش. استنى المعاد اللي قال عليه مدرسك.',
          'expired': 'وقت الامتحان ده خلص. كلم مدرسك.',
          'already_completed': 'الكود ده اتستخدم وخلاص. كلم مدرسك لو في غلط.',
        };
        toast(context, m[r['error']] ?? 'حصلت مشكلة، جرب تاني', err: true);
        setState(() => _busy = false);
        return;
      }
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ExamIntroPage(data: r)));
    } catch (_) {
      if (mounted) { toast(context, 'حصلت مشكلة في الاتصال، جرب تاني', err: true); setState(() => _busy = false); }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('دخول الامتحان')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('بوابة الامتحانات', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
                const SizedBox(height: 6),
                Text('اكتب الكود اللي المدرس بعتهولك', style: TextStyle(color: Colors.grey.shade600), textAlign: TextAlign.center),
                const SizedBox(height: 16),
                TextField(
                  controller: _code,
                  textCapitalization: TextCapitalization.characters,
                  textDirection: TextDirection.ltr, textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 20, letterSpacing: 3, fontWeight: FontWeight.w800),
                  decoration: const InputDecoration(hintText: 'XXXX-XXXX'),
                  onSubmitted: (_) => _redeem(),
                ),
                const SizedBox(height: 16),
                BusyBtn(label: 'دخول', busy: _busy, onTap: _redeem, icon: Icons.login),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

class ExamIntroPage extends StatelessWidget {
  final Map data;
  const ExamIntroPage({super.key, required this.data});
  @override
  Widget build(BuildContext context) {
    final exam = data['exam'] as Map;
    final qs = (data['questions'] as List?) ?? [];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تفاصيل الامتحان')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(children: [
                  Text(exam['title'] ?? '', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
                  const SizedBox(height: 6),
                  Text('${exam['subject'] ?? ''} ${exam['grade'] ?? ''}', style: TextStyle(color: Colors.grey.shade600)),
                  const Divider(height: 28),
                  _row('الطالب', data['student'] ?? ''),
                  _row('عدد الأسئلة', '${qs.length}'),
                  _row('المدة', fmtDur(exam['duration_min'] ?? 15)),
                  _row('نسبة النجاح', '${exam['pass_pct'] ?? 50}%'),
                ]),
              ),
            ),
            const SizedBox(height: 12),
            Text('بالتوفيق يا بطل! خد نفسك وركّز.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade700)),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => TakeExamPage(data: data))),
              icon: const Icon(Icons.play_arrow), label: const Text('ابدأ الامتحان'),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _row(String k, String v) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(k, style: TextStyle(color: Colors.grey.shade600)),
          Text(v, style: const TextStyle(fontWeight: FontWeight.w700)),
        ]),
      );
}

class TakeExamPage extends StatefulWidget {
  final Map data;
  const TakeExamPage({super.key, required this.data});
  @override
  State<TakeExamPage> createState() => _TakeExamPageState();
}

class _TakeExamPageState extends State<TakeExamPage> with WidgetsBindingObserver {
  late List _questions;
  late Map _answers; // question_id -> dynamic (int index for mcq/tf, string for sa/essay)
  late DateTime _startedAt;
  late int _durationSec;
  Timer? _timer;
  int _remaining = 0;
  int _index = 0;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final exam = widget.data['exam'] as Map;
    _questions = List.from(widget.data['questions'] ?? []);
    if (exam['shuffle_q'] == true) _questions.shuffle(Random());
    // choices carry their original index so shuffled display still grades right
    for (final q in _questions) {
      if (q['type'] == 'mcq' && q['choices'] is List) {
        final mapped = [for (var i = 0; i < (q['choices'] as List).length; i++) {'t': q['choices'][i], 'i': i}];
        if (exam['shuffle_c'] == true) mapped.shuffle(Random());
        q['choices'] = mapped;
      } else if (q['type'] == 'tf') {
        q['choices'] = [
          {'t': (q['choices'] as List)[0], 'i': 0},
          {'t': (q['choices'] as List)[1], 'i': 1},
        ];
      }
    }
    _answers = Map.from(widget.data['saved'] ?? {});
    _startedAt = DateTime.tryParse(widget.data['exam']['started_at'] ?? '') ?? DateTime.now();
    _durationSec = (widget.data['exam']['duration_min'] ?? 15) * 60;
    final elapsed = DateTime.now().difference(_startedAt.toLocal()).inSeconds;
    _remaining = (_durationSec - elapsed).clamp(0, _durationSec);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_remaining <= 1) { t.cancel(); _submit(auto: true); return; }
      if (mounted) setState(() => _remaining--);
    });
  }

  @override
  void dispose() { _timer?.cancel(); WidgetsBinding.instance.removeObserver(this); super.dispose(); }

  String _saveNote = '';
  bool _expired = false;

  void _save(dynamic qid, dynamic answer) {
    _answers[qid] = answer;
    if (mounted) setState(() => _saveNote = 'جاري الحفظ…');
    sb.rpc('save_answer', params: {'p_session': widget.data['session_id'], 'p_question': qid, 'p_answer': answer}).then((r) {
      if (!mounted) return;
      if (r is Map && (r['rejected'] == 'time_expired' || r['error'] == 'time_expired')) {
        // server says time is over: stop editing and hand in what was saved
        if (!_expired) { _expired = true; _submit(auto: true); }
        return;
      }
      setState(() => _saveNote = (r is Map && r['ok'] == false) ? 'مشكلة في الحفظ، اتأكد من النت' : '✓ اتحفظت');
    }).catchError((_) { if (mounted) setState(() => _saveNote = 'مشكلة في الحفظ، اتأكد من النت'); });
  }

  Future<void> _submit({bool auto = false}) async {
    if (_submitting) return;
    if (!auto) {
      final yes = await showDialog<bool>(
        context: context,
        builder: (ctx) => Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: const Text('تسليم الامتحان؟'),
            content: const Text('متأكد إنك عايز تسلّم؟ مش هتقدر ترجع بعدها.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لسه')),
              ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('سلّم')),
            ],
          ),
        ),
      );
      if (yes != true) return;
    }
    setState(() => _submitting = true);
    try {
      final timeSec = DateTime.now().difference(_startedAt.toLocal()).inSeconds;
      final r = await sb.rpc('submit_exam', params: {
        'p_session': widget.data['session_id'], 'p_time_sec': timeSec, 'p_auto': auto,
      });
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ExamResultPage(result: r, student: widget.data['student'] ?? '')));
    } catch (_) {
      if (mounted) { toast(context, 'حصلت مشكلة في التسليم، جرب تاني', err: true); setState(() => _submitting = false); }
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = _questions[_index];
    final mins = (_remaining ~/ 60).toString().padLeft(2, '0');
    final secs = (_remaining % 60).toString().padLeft(2, '0');
    final low = _remaining < 60;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: PopScope(
        canPop: false,
        child: Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            title: Text('سؤال ${_index + 1} من ${_questions.length}'),
            actions: [
              Center(child: Container(
                margin: const EdgeInsetsDirectional.only(end: 14),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: low ? kTeal : (_remaining < 300 ? kGold : Colors.white),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kNavy, width: 2),
                ),
                child: Text('$mins:$secs', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: low ? Colors.white : kNavy)),
              )),
            ],
          ),
          body: Column(children: [
            LinearProgressIndicator(minHeight: 7, value: (_index + 1) / _questions.length, color: kTeal, backgroundColor: const Color(0xFFEADFC9)),
            Expanded(
              child: ListView(padding: const EdgeInsets.all(20), children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Text(q['text'] ?? '', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text('${q['points']} درجة', style: TextStyle(color: Colors.grey.shade500, fontSize: 12)),
                      const SizedBox(height: 16),
                      _answerWidget(q),
                    ]),
                  ),
                ),
              ]),
            ),
            if (_saveNote.isNotEmpty)
              Padding(padding: const EdgeInsets.only(top: 6), child: Text(_saveNote, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _saveNote.startsWith('✓') ? const Color(0xFF2F8F5B) : (_saveNote.startsWith('مشكلة') ? Colors.red.shade700 : Colors.grey.shade600)))),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                if (_index > 0)
                  Expanded(child: OutlinedButton(onPressed: () => setState(() => _index--), child: const Text('السابق'))),
                if (_index > 0) const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: _index < _questions.length - 1
                      ? ElevatedButton(onPressed: () => setState(() => _index++), child: const Text('اللي بعده'))
                      : BusyBtn(label: 'تسليم الامتحان', busy: _submitting, onTap: () => _submit(), icon: Icons.check),
                ),
              ]),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _answerWidget(Map q) {
    final qid = q['id'];
    final type = q['type'];
    if (type == 'mcq' || type == 'tf') {
      final choices = (q['choices'] as List?) ?? [];
      final sel = _answers[qid];
      return Column(
        children: List.generate(choices.length, (row) {
          final origIdx = choices[row]['i'];
          final isSel = sel == origIdx || (sel is String && sel == '$origIdx');
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => setState(() => _save(qid, origIdx)),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                decoration: BoxDecoration(
                  color: isSel ? kMint : Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: kNavy, width: 2),
                  boxShadow: isSel ? const [BoxShadow(color: kNavy, offset: Offset(3, 3))] : null,
                ),
                child: Row(children: [
                  Container(
                    width: 32, height: 32, alignment: Alignment.center,
                    decoration: BoxDecoration(color: isSel ? kNavy : kBg, borderRadius: BorderRadius.circular(10), border: Border.all(color: kNavy, width: 2)),
                    child: Text(row < 4 ? 'أبجد'[row] : '${row + 1}', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14, color: isSel ? Colors.white : kNavy)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Text('${choices[row]['t']}', style: const TextStyle(color: kNavy, fontWeight: FontWeight.w700, fontSize: 15))),
                ]),
              ),
            ),
          );
        }),
      );
    }
    // sa / essay: free text
    return TextField(
      maxLines: type == 'essay' ? 6 : 2,
      controller: TextEditingController(text: _answers[qid]?.toString() ?? ''),
      decoration: InputDecoration(hintText: type == 'essay' ? 'اكتب إجابتك بالتفصيل...' : 'اكتب إجابتك...'),
      onChanged: (v) => _save(qid, v),
    );
  }
}

class ExamResultPage extends StatelessWidget {
  final Map result;
  final String student;
  const ExamResultPage({super.key, required this.result, required this.student});
  @override
  Widget build(BuildContext context) {
    final show = result['show'] == true;
    final score = result['score'], total = result['total'];
    final p = (total is num && total > 0 && score is num) ? (score / total * 100).round() : 0;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              FadeSlideIn(
                child: Container(
                  padding: const EdgeInsets.all(22),
                  decoration: const BoxDecoration(color: kNavy, shape: BoxShape.circle),
                  child: const Icon(Icons.emoji_events, color: kGold, size: 54),
                ),
              ),
              const SizedBox(height: 18),
              Text('برافو يا $student!', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text('امتحانك اتسلّم بنجاح', style: TextStyle(color: Colors.grey.shade600)),
              const SizedBox(height: 16),
              if (show && result['ok'] == true) ...[
                Card(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 18),
                    child: Column(children: [
                      Text('$score / $total', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: kNavy)),
                      Text('$p%', style: TextStyle(color: Colors.grey.shade600, fontSize: 16)),
                      if (result['essay_pending'] == true)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text('في أسئلة مقالية هتتصحح من المدرس', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                        ),
                    ]),
                  ),
                ),
              ] else
                Text('النتيجة هتتقاللك من مدرسك', style: TextStyle(color: Colors.grey.shade600)),
              const SizedBox(height: 24),
              ElevatedButton(onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst), child: const Text('تمام')),
            ]),
          ),
        ),
      ),
    );
  }
}
