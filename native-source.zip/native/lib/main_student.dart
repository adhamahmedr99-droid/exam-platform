import 'package:flutter/material.dart';
import 'src/core.dart';
import 'student/landing.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initSupabase();
  runApp(const StudentApp());
}

class StudentApp extends StatefulWidget {
  const StudentApp({super.key});
  @override
  State<StudentApp> createState() => _StudentAppState();
}

class _StudentAppState extends State<StudentApp> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => checkForUpdate(context, 'student'));
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'المنصة للطالب',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const StudentLanding(),
    );
  }
}
