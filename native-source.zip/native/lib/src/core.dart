import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:ota_update/ota_update.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const kSupabaseUrl = 'https://lrlwdktnlmfxhpwcnskn.supabase.co';
const kSupabaseAnonKey = 'sb_publishable_nPTht0gtZDeKzJH1J4NpTA_Pfb-jbam';
const kSiteUrl = 'https://adhamahmedr99-droid.github.io/exam-platform/';
const kVodafoneCashNumber = '01282948205';

SupabaseClient get sb => Supabase.instance.client;

Future<void> initSupabase() async {
  await Supabase.initialize(url: kSupabaseUrl, anonKey: kSupabaseAnonKey);
}

// ---------- Theme (Design B "الكراسة") ----------
const kNavy = Color(0xFF2B2118);   // ink (kept name: used all over)
const kNavy2 = Color(0xFF4A3828);
const kTeal = Color(0xFFFF6B4A);   // coral accent
const kGold = Color(0xFFFFC83D);   // sun
const kMint = Color(0xFF7EE0A8);
const kBg = Color(0xFFFBF3E4);     // paper
const kCharcoal = Color(0xFF14171F);

ThemeData buildTheme({bool teacher = false}) {
  final base = ThemeData.light(useMaterial3: true);
  final bar = teacher ? kCharcoal : kBg;
  final barFg = teacher ? Colors.white : kNavy;
  return base.copyWith(
    scaffoldBackgroundColor: kBg,
    colorScheme: ColorScheme.fromSeed(seedColor: kTeal, primary: kNavy, secondary: kTeal, surface: kBg),
    textTheme: base.textTheme.apply(fontFamily: 'Cairo', bodyColor: kNavy, displayColor: kNavy),
    primaryTextTheme: base.primaryTextTheme.apply(fontFamily: 'Cairo'),
    appBarTheme: AppBarTheme(
      backgroundColor: bar, foregroundColor: barFg, centerTitle: true, elevation: 0, scrolledUnderElevation: 0,
      titleTextStyle: TextStyle(fontFamily: 'Cairo', fontSize: 19, fontWeight: FontWeight.w800, color: barFg),
    ),
    cardTheme: CardThemeData(
      color: Colors.white, elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: kNavy, width: 2)),
      margin: const EdgeInsets.symmetric(vertical: 6),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: kNavy, width: 1.5)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: kNavy, width: 1.5)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: kTeal, width: 2.5)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: kNavy, foregroundColor: Colors.white, elevation: 0,
        minimumSize: const Size.fromHeight(54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w800),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: kNavy, minimumSize: const Size.fromHeight(54),
        side: const BorderSide(color: kNavy, width: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w800),
      ),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}

// ---------- Shared widgets ----------
class BrandHeader extends StatelessWidget {
  final String subtitle;
  const BrandHeader({super.key, this.subtitle = ''});
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(22, 56, 22, 30),
      decoration: const BoxDecoration(
        color: kTeal,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
        border: Border(bottom: BorderSide(color: kNavy, width: 3)),
      ),
      child: Column(children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: kBg, shape: BoxShape.circle, border: Border.all(color: kNavy, width: 2.5)),
          child: const Icon(Icons.auto_stories, color: kNavy, size: 40),
        ),
        const SizedBox(height: 12),
        const Text('المنصة', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900)),
        if (subtitle.isNotEmpty) ...[
          const SizedBox(height: 4),
          Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 13.5, height: 1.6)),
        ],
      ]),
    );
  }
}

class PwField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final TextInputAction? action;
  final void Function(String)? onSubmit;
  const PwField({super.key, required this.controller, this.label = 'كلمة السر', this.action, this.onSubmit});
  @override
  State<PwField> createState() => _PwFieldState();
}

class _PwFieldState extends State<PwField> {
  bool _hide = true;
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: widget.controller,
      obscureText: _hide,
      textInputAction: widget.action,
      onSubmitted: widget.onSubmit,
      decoration: InputDecoration(
        labelText: widget.label,
        prefixIcon: IconButton(
          icon: Icon(_hide ? Icons.visibility_off : Icons.visibility, size: 20),
          onPressed: () => setState(() => _hide = !_hide),
        ),
      ),
    );
  }
}

void toast(BuildContext ctx, String msg, {bool err = false}) {
  ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
    content: Text(msg, textAlign: TextAlign.center),
    backgroundColor: err ? Colors.red.shade700 : kNavy,
  ));
}

class BusyBtn extends StatelessWidget {
  final String label;
  final bool busy;
  final VoidCallback? onTap;
  final IconData? icon;
  const BusyBtn({super.key, required this.label, required this.busy, this.onTap, this.icon});
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: busy ? null : onTap,
      child: busy
          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.4))
          : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              if (icon != null) ...[Icon(icon, size: 19), const SizedBox(width: 8)],
              Text(label),
            ]),
    );
  }
}

// Animated entrance wrapper (light animation for login screens)
class FadeSlideIn extends StatefulWidget {
  final Widget child;
  final int delayMs;
  const FadeSlideIn({super.key, required this.child, this.delayMs = 0});
  @override
  State<FadeSlideIn> createState() => _FadeSlideInState();
}

class _FadeSlideInState extends State<FadeSlideIn> with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fade = CurvedAnimation(parent: _c, curve: Curves.easeOut);
    _slide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero).animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic));
    Future.delayed(Duration(milliseconds: widget.delayMs), () { if (mounted) _c.forward(); });
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(opacity: _fade, child: SlideTransition(position: _slide, child: widget.child));
}

// ---------- Helpers ----------
String token6() {
  const a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  final r = Random.secure();
  return List.generate(6, (_) => a[r.nextInt(a.length)]).join();
}
String newToken() => token6() + token6();

String ytId(String url) {
  final m = RegExp(r'(?:youtube\.com/(?:watch\?[^#]*v=|shorts/|embed/)|youtu\.be/)([\w-]{6,})').firstMatch(url);
  return m == null ? '' : m.group(1)!;
}
String driveId(String url) {
  final m = RegExp(r'drive\.google\.com/file/d/([\w-]+)').firstMatch(url);
  return m == null ? '' : m.group(1)!;
}

String fmtDur(int min) => '$min دقيقة';
String pct(num a, num b) => b == 0 ? '0%' : '${(a / b * 100).round()}%';

// ---------- Grade stages ----------
const kStages = [
  'الصف الرابع الابتدائي',
  'الصف الخامس الابتدائي',
  'الصف السادس الابتدائي',
  'الصف الأول الإعدادي',
  'الصف الثاني الإعدادي',
  'الصف الثالث الإعدادي',
];

// ---------- WhatsApp ----------
String waPhone(String phone) {
  var d = phone.replaceAll(RegExp(r'\D'), '');
  if (d.startsWith('0020')) d = d.substring(2);
  if (d.startsWith('0')) d = '2$d';
  return d;
}
Uri waLink(String phone, String text) =>
    Uri.parse('https://wa.me/${waPhone(phone)}?text=${Uri.encodeComponent(text)}');

// ---------- In-app update checker ----------
// Fetches app-version.json from the site; if a newer versionCode exists, offers
// a one-tap update (downloads the APK; installs over the current app - no uninstall).
const kVersionUrl = 'https://adhamahmedr99-droid.github.io/exam-platform/app-version.json';
Future<void> checkForUpdate(BuildContext context, String appKey) async {
  try {
    final info = await PackageInfo.fromPlatform();
    final res = await http.get(Uri.parse(kVersionUrl)).timeout(const Duration(seconds: 8));
    if (res.statusCode != 200) return;
    final j = jsonDecode(res.body);
    if (j is! Map || j[appKey] is! Map) return;
    final m = j[appKey] as Map;
    final latest = (m['versionCode'] as num?)?.toInt() ?? 0;
    final current = int.tryParse(info.buildNumber) ?? 0;
    if (latest <= current || !context.mounted) return;
    final url = m['apk']?.toString() ?? '';
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Directionality(textDirection: TextDirection.rtl, child: _UpdateDialog(url: url, versionName: '${m['versionName'] ?? ''}')),
    );
  } catch (_) {/* offline or no update info: stay quiet */}
}


// ---------- About us ----------
class AboutPage extends StatelessWidget {
  final bool teacher;
  const AboutPage({super.key, this.teacher = false});
  Widget _sec(String t, String body, IconData ic) => Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Icon(ic, color: kTeal), const SizedBox(width: 8), Text(t, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))]),
            const SizedBox(height: 8),
            Text(body, style: const TextStyle(height: 1.8, fontSize: 14)),
          ]),
        ),
      );
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('عن المنصة')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          _sec('إحنا مين', 'المنصة مكان بسيط للمدرسين والطلبة: المدرس بيعمل الامتحانات ويبعت الكود، والطالب بيحل من موبايله في أي وقت من غير تسجيل حساب.', Icons.auto_stories),
          _sec('للطلبة', 'اكتب الكود اللي مدرسك بعتهولك وابدأ الامتحان. إجاباتك بتتحفظ تلقائيًا، وتقدر تشوف فيديوهات الشرح وتختار مرحلتك من رابعة ابتدائي لحد تالتة إعدادي وتسأل بوت الأسئلة.', Icons.school_outlined),
          _sec('للمدرسين', 'اعمل امتحانك بإيدك أو من ملف أو من صورة، ووزّع أكواد أو لينك مفتوح، وتابع النتايج والتحليلات، وضيف فيديوهات للمشتركين بس.', Icons.edit_note),
          _sec('التحديثات', 'التطبيق بيشوف لو في نسخة جديدة أول ما تفتحه، وبيقولك. المحتوى (الامتحانات والفيديوهات والأسئلة) بيتحدث لوحده من غير ما تنزّل حاجة.', Icons.system_update),
          _sec('خصوصيتك', 'بنحفظ بس اللي لازم عشان الامتحان يشتغل: اسم الطالب وإجاباته. مفيش إعلانات ومش بنبيع أي بيانات.', Icons.lock_outline),
        ]),
      ),
    );
  }
}


class _UpdateDialog extends StatefulWidget {
  final String url, versionName;
  const _UpdateDialog({required this.url, required this.versionName});
  @override
  State<_UpdateDialog> createState() => _UpdateDialogState();
}

class _UpdateDialogState extends State<_UpdateDialog> {
  bool _started = false;
  int _pct = 0;
  String _msg = '';
  bool _failed = false;

  void _go() {
    setState(() { _started = true; _failed = false; _msg = 'جاري تنزيل التحديث…'; _pct = 0; });
    try {
      OtaUpdate().execute(widget.url, destinationFilename: 'manassa-update.apk').listen((e) {
        if (!mounted) return;
        switch (e.status) {
          case OtaStatus.DOWNLOADING:
            setState(() { _pct = int.tryParse(e.value ?? '') ?? _pct; _msg = 'جاري تنزيل التحديث… $_pct%'; });
            break;
          case OtaStatus.INSTALLING:
            setState(() => _msg = 'اضغط "تثبيت" في الشاشة اللي ظهرت. لو اتسألت، اسمح بالتثبيت من التطبيق ده.');
            break;
          case OtaStatus.INSTALLATION_DONE:
            Navigator.of(context).maybePop();
            break;
          case OtaStatus.PERMISSION_NOT_GRANTED_ERROR:
            setState(() { _failed = true; _msg = 'محتاج تسمح للتطبيق بتثبيت التحديثات من الإعدادات، وبعدها جرّب تاني.'; });
            break;
          default:
            setState(() { _failed = true; _msg = 'التحديث ماتنزلش. اتأكد من النت وجرّب تاني، أو حمّله من اللينك.'; });
        }
      }, onError: (_) { if (mounted) setState(() { _failed = true; _msg = 'التحديث ماتنزلش. اتأكد من النت وجرّب تاني، أو حمّله من اللينك.'; }); });
    } catch (_) {
      setState(() { _failed = true; _msg = 'التحديث ماتنزلش. جرّب تاني.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('في تحديث جديد 🎉'),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(_started ? _msg : 'النسخة ${widget.versionName} متاحة. التحديث بينزل جوه التطبيق وبيتثبت فوق الحالي، من غير ما تمسح التطبيق ولا تضيع أي بيانات.'),
        if (_started && !_failed) ...[
          const SizedBox(height: 14),
          LinearProgressIndicator(value: _pct > 0 ? _pct / 100 : null, minHeight: 8, color: kTeal, backgroundColor: const Color(0xFFEADFC9)),
        ],
      ]),
      actions: [
        if (!_started || _failed) TextButton(onPressed: () => Navigator.pop(context), child: const Text('بعدين')),
        if (_failed) TextButton(onPressed: () => launchUrl(Uri.parse(widget.url), mode: LaunchMode.externalApplication), child: const Text('حمّل من اللينك')),
        if (!_started || _failed) ElevatedButton(onPressed: _go, style: ElevatedButton.styleFrom(minimumSize: const Size(110, 46)), child: Text(_failed ? 'جرّب تاني' : 'حدّث دلوقتي')),
      ],
    );
  }
}
