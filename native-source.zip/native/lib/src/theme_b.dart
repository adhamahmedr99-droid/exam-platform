// Design B "الكراسة" tokens. Not wired in yet (prep only).
import 'package:flutter/material.dart';

const kPaper = Color(0xFFFBF3E4);
const kInk = Color(0xFF2B2118);
const kCoral = Color(0xFFFF6B4A);
const kMint = Color(0xFF7EE0A8);
const kSun = Color(0xFFFFC83D);
const kCharcoal = Color(0xFF14171F);
const kCharcoal2 = Color(0xFF1F2430);

ThemeData studentThemeB() => ThemeData(
  useMaterial3: true,
  fontFamily: 'Cairo',
  scaffoldBackgroundColor: kPaper,
  colorScheme: ColorScheme.fromSeed(seedColor: kCoral, surface: kPaper),
  cardTheme: CardThemeData(
    color: Colors.white, elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: kInk, width: 2)),
  ),
);

ThemeData teacherThemeB() => ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  fontFamily: 'Cairo',
  scaffoldBackgroundColor: kCharcoal,
  colorScheme: ColorScheme.fromSeed(seedColor: kSun, brightness: Brightness.dark, surface: kCharcoal),
);
