# المنصة native apps (teacher + student)

Flutter source for the two Android apps (teacher: io.github.adhamahmedr99_droid.twa, student: io.github.adhamahmedr99_droid.student).
Build: flutter build / gradle assembleTeacherRelease -Ptarget=lib/main_teacher.dart (student: assembleStudentRelease -Ptarget=lib/main_student.dart).
Signing: android/app/key.properties and the keystore are NOT in this repo (create your own). The Supabase key in lib/src/core.dart is the public publishable key.
Font: Cairo (OFL), place Cairo[slnt,wght].ttf at assets/fonts/Cairo.ttf (not included here).
Web app and backend schema: see the repo root.
